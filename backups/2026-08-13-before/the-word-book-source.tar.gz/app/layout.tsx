import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NeoMemoria Cards｜自分用単語帳",
  description: "CSV・TSVの取り込みとFSRS-6復習に対応した、自分用の単語帳。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}
