"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { parseRows, type ImportedCard } from "./import-parser";

type AppUser = { email: string; name?: string | null } | null;
type Tab = "overview" | "decks" | "deck" | "study" | "stats";
type StudyMode = "normal" | "simple" | "oni";
type Origin = "remote" | "sample" | "local";

type Card = {
  id: string;
  sortOrder: number;
  word: string;
  meaning: string;
  syntax: string;
  example1: string;
  example2: string;
  emoji: string;
};

type Deck = {
  id: string;
  name: string;
  description: string;
  cardCount: number;
  origin: Origin;
  isOfficial?: boolean;
};

type Stats = {
  due: number;
  reviewed: number;
  retention: number | null;
  streak: number;
  activity: number[];
};

type LastAction = {
  index: number;
  cardId: string;
  logId: string | null;
};

type ReviewState = { cardId: string; dueAt: string };
const SESSION_NEW_LIMIT = 20;

const EMPTY_STATS: Stats = {
  due: 0,
  reviewed: 0,
  retention: null,
  streak: 0,
  activity: Array(12).fill(0),
};

const SAMPLE_DECK: Deck = {
  id: "sample-toefl",
  name: "TOEFL 1915 · Sample",
  description: "保存されないプレビュー用デッキ",
  cardCount: 4,
  origin: "sample",
};

const SAMPLE_CARDS: Card[] = [
  {
    id: "sample-1",
    sortOrder: 1,
    word: "consecutive",
    meaning: "連続した、途切れない",
    syntax: "consecutive days（連続した日々）",
    example1: "The experiment ran for three consecutive days.",
    example2: "実験は3日間連続で行われた。",
    emoji: "↗",
  },
  {
    id: "sample-2",
    sortOrder: 2,
    word: "substantial",
    meaning: "かなりの、相当な、実質的な",
    syntax: "substantial evidence（十分な証拠）",
    example1: "The claim requires substantial evidence.",
    example2: "その主張には十分な証拠が必要だ。",
    emoji: "◫",
  },
  {
    id: "sample-3",
    sortOrder: 3,
    word: "mitigate",
    meaning: "軽減する、和らげる",
    syntax: "mitigate the risk（リスクを軽減する）",
    example1: "Trees can mitigate the urban heat effect.",
    example2: "樹木は都市の熱効果を緩和できる。",
    emoji: "♧",
  },
  {
    id: "sample-4",
    sortOrder: 4,
    word: "plausible",
    meaning: "もっともらしい、妥当と思われる",
    syntax: "a plausible explanation（もっともらしい説明）",
    example1: "The researchers proposed a plausible mechanism.",
    example2: "研究者らは妥当と思われる機構を提案した。",
    emoji: "◇",
  },
];

function quoteCsv(value: string | number) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function safeFileName(value: string) {
  return value.replace(/[\\/:*?"<>|]/g, "_").slice(0, 100) || "deck";
}

function saveTextFile(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

function initials(user: AppUser) {
  const base = user?.name?.trim() || user?.email || "NM";
  const words = base.split(/[\s@._-]+/).filter(Boolean);
  return words.slice(0, 2).map((word) => word[0]?.toUpperCase()).join("") || "NM";
}

function DeckCard({ deck, index, onOpen }: { deck: Deck; index: number; onOpen: () => void }) {
  return (
    <button className={`deck-card deck-${index % 3}`} onClick={onOpen}>
      <span className="deck-top">
        <span className="deck-icon">{index % 3 === 0 ? "Aa" : index % 3 === 1 ? "∴" : "↗"}</span>
        {deck.isOfficial ? <span className="sample-badge official">PDF OCR</span> : deck.origin !== "remote" ? <span className="sample-badge">{deck.origin === "sample" ? "SAMPLE" : "SESSION"}</span> : null}
      </span>
      <strong className="deck-title">{deck.name}</strong>
      <span className="deck-description">{deck.description || "説明はまだありません"}</span>
      <span className="deck-meta">
        <span>{deck.cardCount} cards</span>
        <span className="progress-line"><i style={{ width: "100%" }} /></span>
        <span>{deck.isOfficial ? "公式" : "開く"}</span>
      </span>
    </button>
  );
}

export function NeoMemoriaApp({ user }: { user: AppUser }) {
  const [tab, setTab] = useState<Tab>("overview");
  const [clock, setClock] = useState(() => Date.now());
  const [decks, setDecks] = useState<Deck[]>(user ? [] : [SAMPLE_DECK]);
  const [selected, setSelected] = useState<Deck | null>(null);
  const [cards, setCards] = useState<Card[]>([]);
  const [sessionCards, setSessionCards] = useState<Card[]>([]);
  const [reviewStates, setReviewStates] = useState<ReviewState[]>([]);
  const [localCards, setLocalCards] = useState<Record<string, Card[]>>({});
  const [stats, setStats] = useState<Stats>(EMPTY_STATS);
  const [search, setSearch] = useState("");
  const [cardSearch, setCardSearch] = useState("");
  const [flipped, setFlipped] = useState(false);
  const [studyIndex, setStudyIndex] = useState(0);
  const [studyMode, setStudyMode] = useState<StudyMode>("normal");
  const [reviewed, setReviewed] = useState(0);
  const [lastAction, setLastAction] = useState<LastAction | null>(null);
  const [ratingBusy, setRatingBusy] = useState(false);
  const [toast, setToast] = useState("");
  const [importName, setImportName] = useState("");
  const [importCards, setImportCards] = useState<ImportedCard[]>([]);
  const [oniAnswer, setOniAnswer] = useState("");
  const [oniRating, setOniRating] = useState<1 | 3 | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function refreshLibrary() {
    try {
      const response = await fetch("/api/neo");
      const data = await response.json() as { authenticated?: boolean; decks?: Array<Omit<Deck, "origin">>; stats?: Stats; error?: string };
      if (!response.ok) throw new Error(data.error || "ライブラリを読み込めませんでした");
      if (data.authenticated) {
        setDecks((data.decks ?? []).map((deck) => ({ ...deck, origin: "remote" })));
        setStats(data.stats ?? EMPTY_STATS);
      } else {
        setDecks([SAMPLE_DECK]);
        setStats(EMPTY_STATS);
      }
    } catch {
      setDecks([SAMPLE_DECK]);
      setToast("保存領域を確認できないため、サンプルを表示しています");
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(() => void refreshLibrary(), 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(Date.now()), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  async function loadDeck(deck: Deck, destination: "deck" | "study") {
    setSelected(deck);
    setFlipped(false);
    setStudyIndex(0);
    setReviewed(0);
    setLastAction(null);
    setOniAnswer("");
    setOniRating(null);
    if (deck.origin === "sample") {
      setCards(SAMPLE_CARDS);
      setReviewStates([]);
      if (destination === "study") startStudy(studyMode, SAMPLE_CARDS, []); else setTab(destination);
      return;
    }
    if (deck.origin === "local") {
      const nextCards = localCards[deck.id] ?? [];
      setCards(nextCards);
      setReviewStates([]);
      if (destination === "study") startStudy(studyMode, nextCards, []); else setTab(destination);
      return;
    }
    try {
      const response = await fetch(`/api/neo?deck=${encodeURIComponent(deck.id)}`);
      const data = await response.json() as { cards?: Card[]; reviewStates?: ReviewState[]; error?: string };
      if (!response.ok) throw new Error(data.error || "デッキを開けませんでした");
      const nextCards = data.cards ?? [];
      const nextStates = data.reviewStates ?? [];
      setCards(nextCards);
      setReviewStates(nextStates);
      if (destination === "study") startStudy(studyMode, nextCards, nextStates); else setTab(destination);
    } catch (error) {
      setToast(error instanceof Error ? error.message : "デッキを開けませんでした");
    }
  }

  function buildStudyQueue(sourceCards: Card[], states: ReviewState[]) {
    const stateByCard = new Map(states.map((state) => [state.cardId, state]));
    const due = sourceCards.filter((card) => {
      const state = stateByCard.get(card.id);
      return state && new Date(state.dueAt).getTime() <= clock;
    });
    const fresh = sourceCards.filter((card) => !stateByCard.has(card.id)).slice(0, SESSION_NEW_LIMIT);
    return [...due, ...fresh];
  }

  function startStudy(mode: StudyMode = studyMode, sourceCards: Card[] = cards, states: ReviewState[] = reviewStates) {
    setStudyMode(mode);
    setSessionCards(buildStudyQueue(sourceCards, states));
    setStudyIndex(0);
    setReviewed(0);
    setFlipped(false);
    setLastAction(null);
    setOniAnswer("");
    setOniRating(null);
    setTab("study");
  }

  async function rate(rating: 1 | 2 | 3 | 4) {
    const card = sessionCards[studyIndex];
    if (!card || ratingBusy) return;
    setRatingBusy(true);
    let logId: string | null = null;
    try {
      if (selected?.origin === "remote") {
        const response = await fetch("/api/neo", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "review", cardId: card.id, rating, mode: studyMode }),
        });
        const data = await response.json() as { logId?: string; state?: { dueAt: string }; error?: string };
        if (!response.ok) throw new Error(data.error || "復習を保存できませんでした");
        logId = data.logId ?? null;
        if (data.state?.dueAt) setReviewStates((values) => [...values.filter((state) => state.cardId !== card.id), { cardId: card.id, dueAt: data.state!.dueAt }]);
      }
      setLastAction({ index: studyIndex, cardId: card.id, logId });
      setReviewed((value) => value + 1);
      setStudyIndex((value) => value + 1);
      setFlipped(false);
      setOniAnswer("");
      setOniRating(null);
    } catch (error) {
      setToast(error instanceof Error ? error.message : "復習を保存できませんでした");
    } finally {
      setRatingBusy(false);
    }
  }

  async function undo() {
    if (!lastAction || ratingBusy) return;
    setRatingBusy(true);
    try {
      if (lastAction.logId) {
        const response = await fetch("/api/neo", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "undo-review", logId: lastAction.logId }),
        });
        const data = await response.json() as { error?: string };
        if (!response.ok) throw new Error(data.error || "レビューを取り消せませんでした");
      }
      setStudyIndex(lastAction.index);
      setFlipped(true);
      setReviewed((value) => Math.max(0, value - 1));
      setLastAction(null);
      setToast("直前のレビューを取り消しました");
    } catch (error) {
      setToast(error instanceof Error ? error.message : "レビューを取り消せませんでした");
    } finally {
      setRatingBusy(false);
    }
  }

  function simpleRate(rating: 1 | 3) {
    if (flipped) {
      void rate(rating);
      return;
    }
    setFlipped(true);
    window.setTimeout(() => void rate(rating), 420);
  }

  function checkOniAnswer() {
    const card = sessionCards[studyIndex];
    if (!card || !oniAnswer.trim()) return;
    setOniRating(oniAnswer.trim().toLocaleLowerCase() === card.word.toLocaleLowerCase() ? 3 : 1);
  }

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (tab !== "study" || ratingBusy) return;
      if (studyMode !== "oni" && event.key === " " && !flipped) {
        event.preventDefault();
        setFlipped(true);
        return;
      }
      if (studyMode === "normal" && flipped && ["1", "2", "3", "4"].includes(event.key)) {
        void rate(Number(event.key) as 1 | 2 | 3 | 4);
      }
      if (studyMode === "simple" && ["1", "3"].includes(event.key)) {
        simpleRate(Number(event.key) as 1 | 3);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  async function saveImport() {
    if (!importName.trim() || importCards.length === 0) {
      setToast("デッキ名とカードを指定してください");
      return;
    }
    try {
      if (!user) throw new Error("プレビューでは、このセッション内にだけ追加します");
      const response = await fetch("/api/neo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "create-deck", name: importName, cards: importCards }),
      });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "インポートできませんでした");
      setToast(`${importCards.length}枚を保存しました`);
      setImportCards([]);
      setImportName("");
      await refreshLibrary();
    } catch (error) {
      const id = `local-${Date.now()}`;
      const localDeck: Deck = {
        id,
        name: importName,
        description: "このブラウザーセッションだけのデッキ",
        cardCount: importCards.length,
        origin: "local",
      };
      const converted = importCards.map((card, index) => ({ ...card, id: `${id}-${index + 1}`, sortOrder: card.number ?? index + 1 }));
      setLocalCards((value) => ({ ...value, [id]: converted }));
      setDecks((value) => [localDeck, ...value]);
      setImportCards([]);
      setImportName("");
      setToast(error instanceof Error ? `${error.message}。一時デッキとして追加しました` : "一時デッキとして追加しました");
    }
  }

  function exportNeoMemoria() {
    if (!selected || !cards.length) return;
    const rows = [
      ["No", "word", "meaning", "syntax", "example1", "example2", "emoji"],
      ...cards.map((card) => [
        card.sortOrder,
        card.word,
        card.meaning,
        card.syntax,
        card.example1,
        card.example2,
        card.emoji,
      ]),
    ];
    const csv = rows.map((row) => row.map(quoteCsv).join(",")).join("\r\n");
    saveTextFile(`${safeFileName(selected.name)}.csv`, `\uFEFF${csv}`, "text/csv;charset=utf-8");
    setToast("NeoMemoria 7列CSVを書き出しました");
  }

  function exportAnki() {
    if (!selected || !cards.length) return;
    const tsv = cards.map((card) => [
      card.id,
      card.word,
      card.meaning,
      card.syntax,
      [card.example1, card.example2].filter(Boolean).join("<br>"),
      card.emoji,
      selected.name,
    ].join("\t")).join("\r\n");
    saveTextFile(`${safeFileName(selected.name)}_anki.tsv`, `\uFEFF${tsv}`, "text/tab-separated-values;charset=utf-8");
    setToast("Anki TSVを書き出しました");
  }

  const visibleDecks = useMemo(
    () => decks.filter((deck) => `${deck.name} ${deck.description}`.toLocaleLowerCase().includes(search.toLocaleLowerCase())),
    [decks, search],
  );
  const visibleCards = useMemo(
    () => cards.filter((card) => `${card.word} ${card.meaning} ${card.syntax}`.toLocaleLowerCase().includes(cardSearch.toLocaleLowerCase())),
    [cards, cardSearch],
  );
  const current = sessionCards[studyIndex];
  const complete = sessionCards.length > 0 && studyIndex >= sessionCards.length;
  const completion = sessionCards.length ? Math.min(100, Math.round((reviewed / sessionCards.length) * 100)) : 0;
  const activityMax = Math.max(1, ...stats.activity);
  const identityLabel = user ? (user.name || user.email) : "プレビュー・保存なし";

  return (
    <main className="shell">
      <header className="topbar">
        <button className="brand" onClick={() => setTab("overview")} aria-label="ホームへ">
          <span className="brand-mark">N</span>
          <span>NeoMemoria <span className="brand-accent">Cards</span></span>
        </button>
        <div className="topbar-right">
          <span className={user ? "identity-dot" : "identity-dot preview"} />
          <span>{identityLabel}</span>
          <span className="avatar" aria-hidden="true">{initials(user)}</span>
        </div>
      </header>

      <div className="layout">
        <aside className="sidebar">
          <div className="sidebar-label">メニュー</div>
          <nav aria-label="メインナビゲーション">
            <button className={tab === "overview" ? "nav-item active" : "nav-item"} onClick={() => setTab("overview")}><span>⌂</span>ホーム</button>
            <button className={tab === "decks" || tab === "deck" ? "nav-item active" : "nav-item"} onClick={() => setTab("decks")}><span>▤</span>デッキ</button>
            <button className={tab === "study" ? "nav-item active" : "nav-item"} onClick={() => setTab("study")}><span>◉</span>学習</button>
            <button className={tab === "stats" ? "nav-item active" : "nav-item"} onClick={() => setTab("stats")}><span>◒</span>統計</button>
          </nav>
          <div className="sidebar-foot">
            <div className="streak">◒ <span><strong>{stats.streak}日</strong><small>学習ストリーク</small></span></div>
          </div>
        </aside>

        <section className="content">
          {tab === "overview" && (
            <>
              <div className="home-head">
                <div>
                  <p className="eyebrow">ホーム</p>
                  <h1>今日の学習</h1>
                  <p className="hero-copy">復習 {stats.due}枚 · {decks.length}デッキ</p>
                </div>
                <button className="primary" onClick={() => setTab("decks")}>デッキを開く <span>→</span></button>
              </div>
              <div className="section-head">
                <div><p className="eyebrow">デッキ</p><h2>{decks.length ? "続きから学ぶ" : "最初のデッキを作る"}</h2></div>
                <button className="text-button" onClick={() => setTab("decks")}>すべてのデッキ <span>→</span></button>
              </div>
              {decks.length ? (
                <div className="deck-grid">
                  {decks.slice(0, 3).map((deck, index) => <DeckCard key={deck.id} deck={deck} index={index} onOpen={() => void loadDeck(deck, "deck")} />)}
                </div>
              ) : (
                <div className="library-empty"><strong>まだデッキがありません</strong><p>CSV、TSV、TXTから最初のデッキを追加できます。</p><button className="secondary" onClick={() => setTab("decks")}>取り込みへ</button></div>
              )}
              <div className="quick-row">
                <div><span className="quick-icon">↯</span><div><strong>今日の復習</strong><small>{stats.due ? `期限が来たカードが ${stats.due} 枚あります` : "期限が来たカードはありません"}</small></div></div>
                <button className="secondary" disabled={!decks.length} onClick={() => decks[0] && void loadDeck(decks[0], "study")}>復習する <span>→</span></button>
              </div>
            </>
          )}

          {tab === "decks" && (
            <>
              <div className="page-heading">
                <div><p className="eyebrow coral">YOUR LIBRARY</p><h1>デッキ</h1><p>学びたいことを、ひとつの場所に。</p></div>
                <button className="primary" onClick={() => fileRef.current?.click()}>＋ ファイルを取り込む</button>
                <input
                  ref={fileRef}
                  className="visually-hidden"
                  type="file"
                  accept=".csv,.tsv,.txt"
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (!file) return;
                    setImportName(file.name.replace(/\.(csv|tsv|txt)$/i, ""));
                    void file.text().then((text) => {
                      const parsed = parseRows(text, file.name);
                      setImportCards(parsed);
                      if (!parsed.length) setToast("2・4・6・7列のカードを認識できませんでした");
                    });
                    event.currentTarget.value = "";
                  }}
                />
              </div>
              <div className="import-panel">
                <div><p className="eyebrow">IMPORT</p><h3>{importCards.length ? `${importCards.length}枚を読み込みました` : "CSV / TSV / TXT を追加"}</h3><p>空欄と先頭の掲載番号を保ったまま、2・4・6・7列を判別します。</p></div>
                {importCards.length > 0 && <div className="import-actions"><input value={importName} onChange={(event) => setImportName(event.target.value)} placeholder="デッキ名" /><button className="primary small" onClick={() => void saveImport()}>保存する</button></div>}
              </div>
              <div className="toolbar"><div className="search"><span>⌕</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="デッキを検索" /></div><span className="muted">{visibleDecks.length} decks</span></div>
              {visibleDecks.length ? (
                <div className="deck-grid deck-grid-large">{visibleDecks.map((deck, index) => <DeckCard key={deck.id} deck={deck} index={index} onOpen={() => void loadDeck(deck, "deck")} />)}</div>
              ) : (
                <div className="library-empty"><strong>一致するデッキがありません</strong><p>検索語を変えるか、ファイルを取り込んでください。</p></div>
              )}
            </>
          )}

          {tab === "deck" && selected && (
            <>
              <div className="page-heading deck-detail-heading">
                <div><p className="eyebrow coral">DECK</p><h1>{selected.name}</h1><p>{selected.description || "説明はまだありません"}</p></div>
                <div className="heading-actions"><button className="secondary" onClick={exportAnki}>Anki TSV</button><button className="secondary" onClick={exportNeoMemoria}>7列CSV</button><button className="primary" onClick={() => startStudy()}>今日分を学習 <span>→</span></button></div>
              </div>
              {selected.origin !== "remote" && <div className="notice"><strong>{selected.origin === "sample" ? "サンプルデッキ" : "一時デッキ"}</strong><span>このデッキの復習履歴は保存されません。</span></div>}
              <div className="deck-summary"><div><small>CARDS</small><strong>{cards.length}</strong></div><div><small>ALGORITHM</small><strong>FSRS-6</strong></div><div><small>ORDER</small><strong>掲載順</strong></div></div>
              <div className="toolbar"><div className="search"><span>⌕</span><input value={cardSearch} onChange={(event) => setCardSearch(event.target.value)} placeholder="単語・意味・構文を検索" /></div><span className="muted">{visibleCards.length} cards</span></div>
              <div className="card-table" role="table" aria-label="カード一覧">
                {visibleCards.map((card) => <div className="card-row" role="row" key={card.id}><span className="card-number">{String(card.sortOrder).padStart(4, "0")}</span><strong>{card.word}</strong><span>{card.meaning}</span><small>{card.syntax || "—"}</small></div>)}
              </div>
            </>
          )}

          {tab === "study" && (
            <>
              <div className="study-heading">
                <div><p className="eyebrow coral">FOCUS SESSION</p><h1>{selected?.name ?? "学習セッション"}</h1><p>{sessionCards.length ? `${Math.min(studyIndex + 1, sessionCards.length)} / ${sessionCards.length} cards` : cards.length ? "今日のキューは空です" : "デッキを選んで学習を開始"}</p></div>
                <div className="mode-switch" aria-label="学習モード">
                  {(["normal", "simple", "oni"] as StudyMode[]).map((mode) => <button key={mode} className={studyMode === mode ? "selected" : ""} onClick={() => startStudy(mode)}>{mode === "normal" ? "Normal" : mode === "simple" ? "Simple" : "鬼モード"}</button>)}
                </div>
              </div>
              {!cards.length ? (
                <div className="empty-state"><p>デッキを選択すると、ここで学習できます。</p><button className="primary" onClick={() => setTab("decks")}>デッキを見る</button></div>
              ) : !sessionCards.length ? (
                <div className="complete-card"><span>ALL CAUGHT UP</span><strong>このキューは完了です</strong><p>期限到来カードがなく、次の新規{SESSION_NEW_LIMIT}枚もありません。</p><div><button className="secondary" onClick={() => selected && void loadDeck(selected, "deck")}>デッキへ戻る</button></div></div>
              ) : complete ? (
                <div className="complete-card"><span>SESSION COMPLETE</span><strong>{reviewed}枚を復習しました</strong><p>{selected?.origin === "remote" ? "復習状態はFSRS-6で保存されています。" : "サンプルのため復習状態は保存されていません。"}</p><div><button className="secondary" onClick={() => selected && void loadDeck(selected, "deck")}>デッキへ戻る</button><button className="primary" onClick={() => startStudy()}>次の学習キュー</button></div></div>
              ) : current ? (
                <div className="study-wrap">
                  <div className="study-progress"><span style={{ width: `${Math.max(4, completion)}%` }} /><small>{completion}% complete</small></div>
                  {studyMode === "oni" ? (
                    <div className="oni-card">
                      <span className="card-kicker">SPELLING</span>
                      <strong>{current.meaning}</strong>
                      {current.syntax && <p>{current.syntax}</p>}
                      {current.emoji && <span className="study-emoji">{current.emoji}</span>}
                      <form onSubmit={(event) => { event.preventDefault(); checkOniAnswer(); }}>
                        <input value={oniAnswer} onChange={(event) => { setOniAnswer(event.target.value); setOniRating(null); }} placeholder="英単語を入力" autoCapitalize="off" autoCorrect="off" spellCheck={false} aria-label="英単語のスペル" />
                        <button className="primary" disabled={!oniAnswer.trim() || ratingBusy}>判定</button>
                      </form>
                      {oniRating && <div className={oniRating === 3 ? "oni-result correct" : "oni-result wrong"}><span>{oniRating === 3 ? "正解" : `正解: ${current.word}`}</span><button className="secondary" onClick={() => void rate(oniRating)} disabled={ratingBusy}>結果を記録して次へ</button></div>}
                    </div>
                  ) : (
                    <button className={`flashcard ${flipped ? "is-flipped" : ""}`} onClick={() => setFlipped((value) => !value)}>
                      <span className="card-kicker">{flipped ? "MEANING" : studyMode === "simple" ? "QUICK RECALL" : `#${String(current.sortOrder).padStart(4, "0")}`}</span>
                      <strong>{flipped ? current.meaning : current.word}</strong>
                      {!flipped && studyMode === "normal" && current.emoji && <span className="study-emoji">{current.emoji}</span>}
                      {flipped && studyMode === "normal" && <div className="answer-details">{current.syntax && <p><b>構文</b>{current.syntax}</p>}{current.example1 && <p>{current.example1}</p>}{current.example2 && <p>{current.example2}</p>}</div>}
                      <span className="flip-hint">{flipped ? "評価を選択してください" : "クリックまたは Space で答えを見る"}</span>
                    </button>
                  )}
                  {studyMode === "normal" && flipped && <div className="ratings"><button disabled={ratingBusy} onClick={() => void rate(1)}><b>1</b><span>もう一度</span><small>Again</small></button><button disabled={ratingBusy} onClick={() => void rate(2)}><b>2</b><span>難しい</span><small>Hard</small></button><button disabled={ratingBusy} onClick={() => void rate(3)}><b>3</b><span>覚えた</span><small>Good</small></button><button disabled={ratingBusy} onClick={() => void rate(4)}><b>4</b><span>かんたん</span><small>Easy</small></button></div>}
                  {studyMode === "simple" && <div className="simple-ratings"><button disabled={ratingBusy} className="simple-wrong" onClick={() => simpleRate(1)}><span>×</span>忘れた <small>1</small></button><button disabled={ratingBusy} className="simple-correct" onClick={() => simpleRate(3)}><span>○</span>覚えた <small>3</small></button></div>}
                  <div className="study-footer"><button className="text-button" onClick={() => void undo()} disabled={!lastAction || ratingBusy}>↶ 取り消す</button><button className="text-button" onClick={() => selected && void loadDeck(selected, "deck")}>デッキへ戻る</button></div>
                </div>
              ) : null}
            </>
          )}

          {tab === "stats" && (
            <>
              <div className="page-heading"><div><p className="eyebrow coral">YOUR PROGRESS</p><h1>統計</h1><p>保存済みの復習ログだけを集計します。</p></div></div>
              <div className="stat-grid">
                <div className="stat-card featured"><small>RETENTION RATE</small><strong>{stats.retention ?? "—"}{stats.retention !== null && <span>%</span>}</strong><p>{stats.reviewed ? "Good / Easy の割合" : "学習後に表示されます"}</p><div className="spark">{stats.activity.slice(-9).map((value, index) => <i key={index} style={{ height: `${Math.max(8, Math.round(value / activityMax * 100))}%` }} />)}</div></div>
                <div className="stat-card"><small>REVIEWS</small><strong>{stats.reviewed + reviewed}</strong><p>保存済みレビュー</p><span className="stat-trend">期限到来 {stats.due}枚</span></div>
                <div className="stat-card"><small>STREAK</small><strong>{stats.streak}<span> days</span></strong><p>日本時間での連続学習</p><span className="stat-trend warm">Keep going.</span></div>
              </div>
              <div className="activity-card"><div className="section-head"><div><p className="eyebrow">ACTIVITY</p><h2>学習のリズム</h2></div><span className="muted">過去 12 週間</span></div><div className="activity-chart">{stats.activity.map((value, index) => <div key={index}><i style={{ height: `${Math.max(3, Math.round(value / activityMax * 100))}%` }} /><small>{index % 2 === 0 ? `${12 - index}週前` : ""}</small></div>)}</div></div>
            </>
          )}
        </section>
      </div>
      {toast && <button className="toast" onClick={() => setToast("")}>{toast}　×</button>}
    </main>
  );
}
