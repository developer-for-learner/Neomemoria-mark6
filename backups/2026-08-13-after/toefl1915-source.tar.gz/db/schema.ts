import { sql } from "drizzle-orm";
import { index, integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const reviewStates = sqliteTable(
  "review_states",
  {
    id: text("id").primaryKey(),
    userEmail: text("user_email").notNull(),
    entryId: text("entry_id").notNull(),
    due: text("due").notNull(),
    stability: real("stability").notNull().default(0),
    difficulty: real("difficulty").notNull().default(0),
    elapsedDays: integer("elapsed_days").notNull().default(0),
    scheduledDays: integer("scheduled_days").notNull().default(0),
    learningSteps: integer("learning_steps").notNull().default(0),
    reps: integer("reps").notNull().default(0),
    lapses: integer("lapses").notNull().default(0),
    state: integer("state").notNull().default(0),
    lastReview: text("last_review"),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("review_states_user_entry_unique").on(
      table.userEmail,
      table.entryId,
    ),
    index("review_states_user_due_idx").on(table.userEmail, table.due),
  ],
);

export const reviewLogs = sqliteTable(
  "review_logs",
  {
    id: text("id").primaryKey(),
    reviewStateId: text("review_state_id").notNull(),
    userEmail: text("user_email").notNull(),
    entryId: text("entry_id").notNull(),
    rating: integer("rating").notNull(),
    stateBefore: integer("state_before").notNull(),
    dueBefore: text("due_before").notNull(),
    stabilityBefore: real("stability_before").notNull(),
    difficultyBefore: real("difficulty_before").notNull(),
    elapsedDays: integer("elapsed_days").notNull(),
    scheduledDays: integer("scheduled_days").notNull(),
    reviewedAt: text("reviewed_at").notNull(),
  },
  (table) => [
    index("review_logs_user_reviewed_idx").on(
      table.userEmail,
      table.reviewedAt,
    ),
    index("review_logs_entry_idx").on(table.entryId),
  ],
);
