CREATE TABLE `review_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`review_state_id` text NOT NULL,
	`user_email` text NOT NULL,
	`entry_id` text NOT NULL,
	`rating` integer NOT NULL,
	`state_before` integer NOT NULL,
	`due_before` text NOT NULL,
	`stability_before` real NOT NULL,
	`difficulty_before` real NOT NULL,
	`elapsed_days` integer NOT NULL,
	`scheduled_days` integer NOT NULL,
	`reviewed_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `review_logs_user_reviewed_idx` ON `review_logs` (`user_email`,`reviewed_at`);--> statement-breakpoint
CREATE INDEX `review_logs_entry_idx` ON `review_logs` (`entry_id`);--> statement-breakpoint
CREATE TABLE `review_states` (
	`id` text PRIMARY KEY NOT NULL,
	`user_email` text NOT NULL,
	`entry_id` text NOT NULL,
	`due` text NOT NULL,
	`stability` real DEFAULT 0 NOT NULL,
	`difficulty` real DEFAULT 0 NOT NULL,
	`elapsed_days` integer DEFAULT 0 NOT NULL,
	`scheduled_days` integer DEFAULT 0 NOT NULL,
	`learning_steps` integer DEFAULT 0 NOT NULL,
	`reps` integer DEFAULT 0 NOT NULL,
	`lapses` integer DEFAULT 0 NOT NULL,
	`state` integer DEFAULT 0 NOT NULL,
	`last_review` text,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `review_states_user_entry_unique` ON `review_states` (`user_email`,`entry_id`);--> statement-breakpoint
CREATE INDEX `review_states_user_due_idx` ON `review_states` (`user_email`,`due`);