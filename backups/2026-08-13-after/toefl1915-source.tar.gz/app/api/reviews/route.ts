import { and, eq } from "drizzle-orm";
import { createEmptyCard, fsrs, Rating, type Card } from "ts-fsrs";
import { getDb } from "../../../db";
import { reviewLogs, reviewStates } from "../../../db/schema";
import { getChatGPTUser } from "../../chatgpt-auth";
import { VOCABULARY_ENTRIES } from "../../vocabulary-data";

const scheduler = fsrs({
  request_retention: 0.9,
  maximum_interval: 36500,
  enable_fuzz: true,
  enable_short_term: true,
  learning_steps: ["1m", "10m"],
  relearning_steps: ["10m"],
});

type ReviewRow = typeof reviewStates.$inferSelect;

function rowToCard(row: ReviewRow): Card {
  return {
    due: new Date(row.due),
    stability: row.stability,
    difficulty: row.difficulty,
    elapsed_days: row.elapsedDays,
    scheduled_days: row.scheduledDays,
    learning_steps: row.learningSteps,
    reps: row.reps,
    lapses: row.lapses,
    state: row.state,
    last_review: row.lastReview ? new Date(row.lastReview) : undefined,
  } as Card;
}

function cardToValues(card: Card) {
  return {
    due: card.due.toISOString(),
    stability: card.stability,
    difficulty: card.difficulty,
    elapsedDays: card.elapsed_days,
    scheduledDays: card.scheduled_days,
    learningSteps: card.learning_steps,
    reps: card.reps,
    lapses: card.lapses,
    state: card.state,
    lastReview: card.last_review?.toISOString() ?? null,
    updatedAt: new Date().toISOString(),
  };
}

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) {
    return Response.json({ authenticated: false, states: [] });
  }

  const db = await getDb();
  const states = await db
    .select()
    .from(reviewStates)
    .where(eq(reviewStates.userEmail, user.email));

  return Response.json({ authenticated: true, states });
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) {
    return Response.json(
      { error: "プレビュー環境では学習履歴を保存できません。" },
      { status: 401 },
    );
  }

  let payload: { entryId?: string; rating?: number };
  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return Response.json({ error: "JSON形式が正しくありません。" }, { status: 400 });
  }

  const entryId = payload.entryId?.trim() ?? "";
  const rating = Number(payload.rating);
  const entryExists = VOCABULARY_ENTRIES.some((entry) => entry.id === entryId);
  if (!entryExists || ![Rating.Again, Rating.Hard, Rating.Good, Rating.Easy].includes(rating)) {
    return Response.json({ error: "単語IDまたは評価が正しくありません。" }, { status: 400 });
  }

  const db = await getDb();
  const [existing] = await db
    .select()
    .from(reviewStates)
    .where(
      and(
        eq(reviewStates.userEmail, user.email),
        eq(reviewStates.entryId, entryId),
      ),
    )
    .limit(1);

  const now = new Date();
  const before = existing ? rowToCard(existing) : createEmptyCard(now);
  const next = scheduler.next(before, now, rating).card;
  const stateId = existing?.id ?? crypto.randomUUID();
  const values = cardToValues(next);

  await db.batch([
    db
      .insert(reviewStates)
      .values({
        id: stateId,
        userEmail: user.email,
        entryId,
        ...values,
      })
      .onConflictDoUpdate({
        target: reviewStates.id,
        set: values,
      }),
    db.insert(reviewLogs).values({
      id: crypto.randomUUID(),
      reviewStateId: stateId,
      userEmail: user.email,
      entryId,
      rating,
      stateBefore: before.state,
      dueBefore: before.due.toISOString(),
      stabilityBefore: before.stability,
      difficultyBefore: before.difficulty,
      elapsedDays: before.elapsed_days,
      scheduledDays: before.scheduled_days,
      reviewedAt: now.toISOString(),
    }),
  ]);

  return Response.json({ state: { id: stateId, userEmail: user.email, entryId, ...values } });
}
