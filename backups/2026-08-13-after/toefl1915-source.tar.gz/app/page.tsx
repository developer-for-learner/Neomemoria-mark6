import { getChatGPTUser } from "./chatgpt-auth";
import { ToeflApp } from "./toefl-app";

export const dynamic = "force-dynamic";

export default async function Home() {
  const user = await getChatGPTUser();

  return (
    <ToeflApp
      user={
        user
          ? { displayName: user.displayName, email: user.email }
          : null
      }
    />
  );
}
