"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  createEmptyCard,
  fsrs,
  Rating,
  State,
  type Card,
} from "ts-fsrs";
import {
  DATASET_STATUS,
  SOURCE_FILES,
  VOCABULARY_ENTRIES,
  vocabularyLevel,
  type VocabularyEntry,
  type VocabularyLevel,
} from "./vocabulary-data";

type AppUser = { displayName: string; email: string } | null;
type View = "overview" | "study" | "library" | "sources" | "settings";
type DeckFilter = "all" | VocabularyLevel;
type StoredReview = {
  id: string;
  entryId: string;
  due: string;
  stability: number;
  difficulty: number;
  elapsedDays: number;
  scheduledDays: number;
  learningSteps: number;
  reps: number;
  lapses: number;
  state: number;
  lastReview: string | null;
};

const scheduler = fsrs({
  request_retention: 0.9,
  maximum_interval: 36500,
  enable_fuzz: true,
  enable_short_term: true,
  learning_steps: ["1m", "10m"],
  relearning_steps: ["10m"],
});

const SESSION_NEW_LIMIT = 20;

const DECKS: Array<{ id: DeckFilter; label: string; short: string; expected: number }> = [
  { id: "core", label: "最重要単語", short: "最重要", expected: DATASET_STATUS.coreExpected },
  { id: "expanded", label: "発展単語", short: "発展", expected: DATASET_STATUS.expandedExpected },
  { id: "all", label: "最重要＋発展", short: "全範囲", expected: DATASET_STATUS.expectedEntries },
];

const NAV_ITEMS: Array<{ id: View; label: string; icon: string }> = [
  { id: "overview", label: "ホーム", icon: "⌂" },
  { id: "study", label: "学習", icon: "◈" },
  { id: "library", label: "語彙", icon: "⌕" },
  { id: "sources", label: "データ", icon: "◎" },
  { id: "settings", label: "設定", icon: "⚙" },
];

const RATING_META = [
  { rating: Rating.Again, label: "もう一度", key: "1", tone: "again" },
  { rating: Rating.Hard, label: "難しい", key: "2", tone: "hard" },
  { rating: Rating.Good, label: "覚えた", key: "3", tone: "good" },
  { rating: Rating.Easy, label: "簡単", key: "4", tone: "easy" },
] as const;

function storedToCard(review?: StoredReview): Card {
  if (!review) return createEmptyCard(new Date());
  return {
    due: new Date(review.due),
    stability: review.stability,
    difficulty: review.difficulty,
    elapsed_days: review.elapsedDays,
    scheduled_days: review.scheduledDays,
    learning_steps: review.learningSteps,
    reps: review.reps,
    lapses: review.lapses,
    state: review.state,
    last_review: review.lastReview ? new Date(review.lastReview) : undefined,
  } as Card;
}

function cardToStored(entryId: string, card: Card): StoredReview {
  return {
    id: `local-${entryId}`,
    entryId,
    due: card.due.toISOString(),
    stability: card.stability,
    difficulty: card.difficulty,
    elapsedDays: card.elapsed_days,
    scheduledDays: card.scheduled_days,
    learningSteps: card.learning_steps,
    reps: card.reps,
    lapses: card.lapses,
    state: card.state,
    lastReview: card.last_review?.toISOString() ?? null,
  };
}

function formatInterval(date: Date, now: number) {
  const minutes = Math.max(1, Math.round((date.getTime() - now) / 60000));
  if (minutes < 60) return `${minutes}分`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}時間`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}日`;
  const months = Math.round(days / 30);
  if (months < 24) return `${months}か月`;
  return `${Math.round(months / 12)}年`;
}

function quoteCsv(value: string | number) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function saveTextFile(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.hidden = true;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportNeoMemoria(entries: VocabularyEntry[], suffix: string) {
  const header = ["No", "word", "meaning", "syntax", "example1", "example2", "emoji"];
  const rows = entries.map((entry) => [
    entry.number,
    entry.headword,
    entry.meaning,
    entry.syntax.join("、"),
    entry.examples[0]
      ? `${entry.examples[0].sentence}(${entry.examples[0].translation})`
      : "",
    entry.examples[1]
      ? `${entry.examples[1].sentence}(${entry.examples[1].translation})`
      : "",
    "",
  ]);
  const csv = [header, ...rows]
    .map((row) => row.map(quoteCsv).join(","))
    .join("\r\n");
  saveTextFile(`toefl_1915_${suffix}.csv`, `\uFEFF${csv}`, "text/csv;charset=utf-8");
}

function exportAnki(entries: VocabularyEntry[], suffix: string) {
  const rows = entries.map((entry) =>
    [
      entry.id,
      entry.headword,
      entry.meaning,
      entry.syntax.join("<br>"),
      entry.examples
        .map((example) => `${example.sentence}<br>${example.translation}`)
        .join("<hr>"),
      `${entry.source.fileName} / ${entry.source.pageRange}`,
      entry.tags.join(" "),
    ].join("\t"),
  ).join("\r\n");
  saveTextFile(`toefl_1915_${suffix}_anki.tsv`, `\uFEFF${rows}`, "text/tab-separated-values;charset=utf-8");
}

function SourceBadge({ entry }: { entry: VocabularyEntry }) {
  const label = entry.source.verification === "source-verified"
    ? "原典照合済み"
    : entry.source.verification === "headword-verified"
      ? "見出し語を照合済み"
      : "PDF OCR・要確認";
  const description = entry.source.verification === "source-verified"
    ? "全項目を原典照合済み"
    : entry.source.verification === "headword-verified"
      ? "見出し語のみ照合済み"
      : "PDFからOCR抽出。本文フィールドは人の確認前";
  return (
    <span
      className="source-badge"
      title={`${entry.source.fileName}: ${description}`}
    >
      <span className="source-dot" /> {label}
    </span>
  );
}

export function ToeflApp({ user }: { user: AppUser }) {
  const [view, setView] = useState<View>("overview");
  const [deckFilter, setDeckFilter] = useState<DeckFilter>("core");
  const [clock, setClock] = useState(() => Date.now());
  const [reviews, setReviews] = useState<Record<string, StoredReview>>({});
  const [syncState, setSyncState] = useState<"loading" | "synced" | "preview" | "error">("loading");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState(VOCABULARY_ENTRIES[0]?.id ?? "");
  const [queue, setQueue] = useState<VocabularyEntry[]>([]);
  const [sessionStarted, setSessionStarted] = useState(false);
  const [studyIndex, setStudyIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [sessionRatings, setSessionRatings] = useState<number[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [ratingBusy, setRatingBusy] = useState(false);
  const ratingLockRef = useRef(false);

  useEffect(() => {
    let active = true;
    fetch("/api/reviews")
      .then(async (response) => {
        if (!response.ok) throw new Error("review load failed");
        return (await response.json()) as {
          authenticated: boolean;
          states: StoredReview[];
        };
      })
      .then((data) => {
        if (!active) return;
        setReviews(
          Object.fromEntries(data.states.map((state) => [state.entryId, state])),
        );
        setSyncState(data.authenticated ? "synced" : "preview");
      })
      .catch(() => {
        if (active) setSyncState("error");
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(Date.now()), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  const activeEntries = useMemo(
    () => VOCABULARY_ENTRIES.filter(
      (entry) => deckFilter === "all" || vocabularyLevel(entry) === deckFilter,
    ),
    [deckFilter],
  );

  const sortedQueue = useMemo(() => {
    const due = activeEntries
      .filter((entry) => {
        const review = reviews[entry.id];
        return review && new Date(review.due).getTime() <= clock;
      })
      .sort((a, b) => {
        const dueA = new Date(reviews[a.id].due).getTime();
        const dueB = new Date(reviews[b.id].due).getTime();
        return dueA - dueB || Number(a.number) - Number(b.number) || a.number.localeCompare(b.number);
      });
    const fresh = activeEntries
      .filter((entry) => !reviews[entry.id])
      .sort((a, b) => Number(a.number) - Number(b.number) || a.number.localeCompare(b.number))
      .slice(0, SESSION_NEW_LIMIT);
    return [...due, ...fresh];
  }, [activeEntries, clock, reviews]);

  const filteredEntries = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return activeEntries;
    return activeEntries.filter((entry) =>
      [entry.headword, entry.meaning, entry.syntax.join(" "), entry.number]
        .join(" ")
        .toLowerCase()
        .includes(normalized),
    );
  }, [activeEntries, query]);

  const reviewedCount = activeEntries.filter((entry) => reviews[entry.id]).length;
  const dueCount = activeEntries.filter((entry) => {
    const review = reviews[entry.id];
    return review && new Date(review.due).getTime() <= clock;
  }).length;
  const matureCount = activeEntries.filter((entry) => {
    const review = reviews[entry.id];
    return review?.state === State.Review && review.stability >= 21;
  }).length;
  const selectedEntry =
    activeEntries.find((entry) => entry.id === selectedId) ?? activeEntries[0];
  const activeDeck = DECKS.find((deck) => deck.id === deckFilter) ?? DECKS[0];
  const currentCard = queue[studyIndex];
  const sessionFinished = queue.length > 0 && studyIndex >= queue.length;

  const startStudy = useCallback(() => {
    setQueue(sortedQueue);
    setSessionStarted(true);
    setStudyIndex(0);
    setFlipped(false);
    setSessionRatings([]);
    setView("study");
  }, [sortedQueue]);

  const changeDeck = useCallback((next: DeckFilter) => {
    setDeckFilter(next);
    const first = VOCABULARY_ENTRIES.find(
      (entry) => next === "all" || vocabularyLevel(entry) === next,
    );
    setSelectedId(first?.id ?? "");
    setQueue([]);
    setSessionStarted(false);
    setStudyIndex(0);
    setFlipped(false);
  }, []);

  const openStudyLanding = useCallback(() => {
    setQueue([]);
    setSessionStarted(false);
    setStudyIndex(0);
    setFlipped(false);
    setSessionRatings([]);
    setView("study");
  }, []);

  const rateCard = useCallback(
    async (rating: number) => {
      if (!currentCard || !flipped || ratingLockRef.current) return;
      ratingLockRef.current = true;
      setRatingBusy(true);
      const before = storedToCard(reviews[currentCard.id]);
      const optimistic = scheduler.next(before, new Date(), rating).card;
      const optimisticState = cardToStored(currentCard.id, optimistic);
      const previousState = reviews[currentCard.id];
      setReviews((previous) => ({
        ...previous,
        [currentCard.id]: optimisticState,
      }));
      setSessionRatings((previous) => [...previous, rating]);
      setStudyIndex((index) => index + 1);
      setFlipped(false);

      if (syncState !== "synced") {
        ratingLockRef.current = false;
        setRatingBusy(false);
        return;
      }
      try {
        const response = await fetch("/api/reviews", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ entryId: currentCard.id, rating }),
        });
        if (!response.ok) throw new Error("save failed");
        const data = (await response.json()) as { state: StoredReview };
        setReviews((previous) => ({
          ...previous,
          [currentCard.id]: data.state,
        }));
      } catch {
        setReviews((previous) => {
          const next = { ...previous };
          if (previousState) next[currentCard.id] = previousState;
          else delete next[currentCard.id];
          return next;
        });
        setNotice("保存できませんでした。このカードは次回もう一度表示されます。");
      } finally {
        ratingLockRef.current = false;
        setRatingBusy(false);
      }
    },
    [currentCard, flipped, reviews, syncState],
  );

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (view !== "study" || !currentCard || sessionFinished || ratingBusy) return;
      if (event.code === "Space") {
        event.preventDefault();
        setFlipped((value) => !value);
        return;
      }
      if (flipped && ["1", "2", "3", "4"].includes(event.key)) {
        const meta = RATING_META.find((item) => item.key === event.key);
        if (meta) void rateCard(meta.rating);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [currentCard, flipped, rateCard, ratingBusy, sessionFinished, view]);

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setView("overview")} aria-label="ホームへ">
          <span className="brand-mark">T</span>
          <span>
            <strong>TOEFL 1915</strong>
            <small>公式語彙トレーナー</small>
          </span>
        </button>
        <nav className="desktop-nav" aria-label="メインナビゲーション">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              className={view === item.id ? "active" : ""}
              onClick={() => item.id === "study" ? openStudyLanding() : setView(item.id)}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="account-pill">
          <span className={`sync-dot ${syncState}`} />
          <span>
            <strong>{user?.displayName ?? "プレビュー"}</strong>
            <small>
              {syncState === "synced"
                ? "履歴を保存中"
                : syncState === "loading"
                  ? "接続確認中"
                  : "保存なし"}
            </small>
          </span>
        </div>
      </header>

      <main className={view === "study" ? "main-content study-main" : "main-content"}>
        {notice && (
          <div className="notice" role="status">
            <span>{notice}</span>
            <button onClick={() => setNotice(null)} aria-label="閉じる">×</button>
          </div>
        )}

        <section className="deck-switcher" aria-label="学習する単語帳">
          <span>単語帳</span>
          <div>
            {DECKS.map((deck) => {
              const loaded = VOCABULARY_ENTRIES.filter(
                (entry) => deck.id === "all" || vocabularyLevel(entry) === deck.id,
              ).length;
              return (
                <button key={deck.id} className={deckFilter === deck.id ? "active" : ""} onClick={() => changeDeck(deck.id)}>
                  <strong>{deck.short}</strong>
                  <small>{loaded} / {deck.expected}語</small>
                </button>
              );
            })}
          </div>
        </section>

        {view === "overview" && (
          <Overview
            reviewedCount={reviewedCount}
            dueCount={dueCount}
            matureCount={matureCount}
            queue={sortedQueue}
            reviews={reviews}
            total={activeEntries.length}
            expected={activeDeck.expected}
            deckLabel={activeDeck.label}
            now={clock}
            onStart={startStudy}
            onOpenSources={() => setView("sources")}
          />
        )}

        {view === "study" && (
          <StudyView
            queue={queue}
            started={sessionStarted}
            current={currentCard}
            index={studyIndex}
            flipped={flipped}
            finished={sessionFinished}
            ratings={sessionRatings}
            busy={ratingBusy}
            review={currentCard ? reviews[currentCard.id] : undefined}
            now={clock}
            onFlip={() => { if (!ratingBusy) setFlipped((value) => !value); }}
            onRate={(rating) => void rateCard(rating)}
            onStart={startStudy}
            onExit={() => {
              setSessionStarted(false);
              setView("overview");
            }}
          />
        )}

        {view === "library" && (
          <LibraryView
            entries={filteredEntries}
            query={query}
            selected={selectedEntry}
            reviews={reviews}
            onQuery={setQuery}
            onSelect={setSelectedId}
            onStudy={startStudy}
          />
        )}

        {view === "sources" && <SourcesView entries={activeEntries} suffix={deckFilter} />}

        {view === "settings" && <SettingsView />}
      </main>

      <nav className="mobile-nav" aria-label="モバイルナビゲーション">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            className={view === item.id ? "active" : ""}
            onClick={() => item.id === "study" ? openStudyLanding() : setView(item.id)}
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
    </div>
  );
}

function Overview({
  reviewedCount,
  dueCount,
  matureCount,
  queue,
  reviews,
  total,
  expected,
  deckLabel,
  now,
  onStart,
  onOpenSources,
}: {
  reviewedCount: number;
  dueCount: number;
  matureCount: number;
  queue: VocabularyEntry[];
  reviews: Record<string, StoredReview>;
  total: number;
  expected: number;
  deckLabel: string;
  now: number;
  onStart: () => void;
  onOpenSources: () => void;
}) {
  const progress = total ? Math.round((reviewedCount / total) * 100) : 0;
  return (
    <div className="view-stack simple-overview">
      <section className="overview-header">
        <div>
          <span className="section-kicker">{deckLabel}</span>
          <h1>今日の学習</h1>
          <p>前回の続きから始めましょう。今の記憶に合う単語を自動で選びます。</p>
        </div>
        <button className="primary-button" onClick={onStart}>学習を始める</button>
      </section>

      <section className="metric-grid">
        <Metric label="学習済み" value={`${reviewedCount}語`} detail={`全体の ${progress}%`} icon="◒" tone="violet" />
        <Metric label="今日のおすすめ" value={`${dueCount}語`} detail={dueCount ? "先に振り返る単語" : "復習はひと区切り"} icon="↻" tone="cyan" />
        <Metric label="しっかり定着" value={`${matureCount}語`} detail="長く覚えている語" icon="◇" tone="green" />
        <Metric label="原本取得" value={`${DATASET_STATUS.sourcePdfsAvailable} / ${DATASET_STATUS.sourcePdfsTotal} PDF`} detail={`${DATASET_STATUS.scanPagesAvailable}スキャン頁取得済み`} icon="◎" tone="amber" />
      </section>

      <section className="overview-layout">
        <div className="panel queue-panel">
          <div className="panel-heading">
            <div><h2>今日の単語</h2><p>今、振り返ると効果的な語を先に選びます。</p></div>
            <button onClick={onStart}>開く</button>
          </div>
          <div className="queue-list">
            {queue.slice(0, 5).map((entry, index) => {
              const review = reviews[entry.id];
              const due = review && new Date(review.due).getTime() <= now;
              return (
                <button key={entry.id} className="queue-row" onClick={onStart}>
                  <span className="queue-index">{String(index + 1).padStart(2, "0")}</span>
                  <span className="queue-word"><strong>{entry.headword}</strong><small>{entry.meaning}</small></span>
                  <span className={`queue-status ${due ? "due" : review ? "future" : "new"}`}>
                    {due ? "復習" : review ? "予定済み" : "新規"}
                  </span>
                </button>
              );
            })}
            {!queue.length && <div className="queue-empty">今日の学習対象はありません。</div>}
          </div>
        </div>

        <div className="panel dataset-panel">
          <div className="panel-heading">
            <div><h2>収録状況</h2><p>{deckLabel}</p></div>
            <button onClick={onOpenSources}>詳細</button>
          </div>
          <div className="dataset-count"><strong>{total}</strong><span>/ {expected}語</span></div>
          <div className="dataset-progress" aria-label={`収録 ${total} / ${expected}語`}>
            <i style={{ width: `${expected ? Math.round(total / expected * 100) : 0}%` }} />
          </div>
          <dl className="dataset-details">
            <div><dt>学習済み</dt><dd>{reviewedCount}語</dd></div>
            <div><dt>進捗</dt><dd>{progress}%</dd></div>
            <div><dt>定着した語</dt><dd>{matureCount}語</dd></div>
          </dl>
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value, detail, icon, tone }: { label: string; value: string; detail: string; icon: string; tone: string }) {
  return (
    <article className={`metric-card ${tone}`}>
      <span className="metric-icon">{icon}</span>
      <div><small>{label}</small><strong>{value}</strong><span>{detail}</span></div>
    </article>
  );
}

function StudyView({
  queue,
  started,
  current,
  index,
  flipped,
  finished,
  ratings,
  busy,
  review,
  now,
  onFlip,
  onRate,
  onStart,
  onExit,
}: {
  queue: VocabularyEntry[];
  started: boolean;
  current?: VocabularyEntry;
  index: number;
  flipped: boolean;
  finished: boolean;
  ratings: number[];
  busy: boolean;
  review?: StoredReview;
  now: number;
  onFlip: () => void;
  onRate: (rating: number) => void;
  onStart: () => void;
  onExit: () => void;
}) {
  if (started && !queue.length) {
    return (
      <section className="session-complete">
        <div className="complete-mark">0</div>
        <span className="section-kicker">TODAY COMPLETE</span>
        <h1>今日の学習は完了です。</h1>
        <p>今日は追加の学習はありません。また次の学習で続けましょう。</p>
        <div className="complete-actions">
          <button className="primary-button" onClick={onExit}>ホームへ戻る</button>
        </div>
      </section>
    );
  }

  if (!queue.length) {
    return (
      <section className="study-launch">
        <span className="launch-orbit"><i>◈</i></span>
        <span className="section-kicker">今日の学習</span>
        <h1>覚えるべき語だけを、<br />無理のない量で。</h1>
        <p>今の記憶に合った単語を、今日取り組みやすい量だけ用意します。</p>
        <div className="launch-rules">
          <div><kbd>Space</kbd><span>カードをめくる</span></div>
          <div><kbd>1–4</kbd><span>記憶を評価する</span></div>
          <div><strong>{queue.length || "今日分"}</strong><span>学習対象</span></div>
        </div>
        <button className="primary-button launch-button" onClick={onStart}>学習を始める <span>→</span></button>
      </section>
    );
  }

  if (finished) {
    const remembered = ratings.filter((rating) => rating >= Rating.Good).length;
    const score = ratings.length ? Math.round((remembered / ratings.length) * 100) : 0;
    return (
      <section className="session-complete">
        <div className="complete-mark">✓</div>
        <span className="section-kicker">SESSION COMPLETE</span>
        <h1>今日の学習が完了しました。</h1>
        <p>{ratings.length}語の学習セッションを最後まで進めました。</p>
        <div className="complete-stats">
          <div><strong>{ratings.length}</strong><span>評価した語</span></div>
          <div><strong>{score}%</strong><span>想起できた語</span></div>
          <div><strong>{ratings.filter((rating) => rating === Rating.Again).length}</strong><span>再学習</span></div>
        </div>
        <div className="complete-actions">
          <button className="primary-button" onClick={onStart}>もう一度学習</button>
          <button className="quiet-button" onClick={onExit}>ホームへ戻る</button>
        </div>
      </section>
    );
  }

  if (!current) return null;
  const card = storedToCard(review);
  const previews = scheduler.repeat(card, new Date(now));
  return (
    <section className="study-stage" aria-busy={busy}>
      <div className="study-toolbar">
        <button onClick={onExit} aria-label="学習を終了">×</button>
        <div className="study-progress"><span><i style={{ width: `${((index + 1) / queue.length) * 100}%` }} /></span><small>{index + 1} / {queue.length}</small></div>
        <span className="study-status">自動復習</span>
      </div>

      <button type="button" className={`flashcard ${flipped ? "flipped" : ""}`} onClick={onFlip} aria-label={flipped ? "表面に戻す" : "答えを見る"}>
        {!flipped ? (
          <div className="card-front">
            <div className="card-meta"><span>#{current.number}</span><SourceBadge entry={current} /></div>
            <div className="word-block"><span>HEADWORD</span><h1>{current.headword}</h1><i /></div>
            <p>意味を思い出してからカードをめくる</p>
            <span className="flip-hint"><kbd>Space</kbd> 答えを見る</span>
          </div>
        ) : (
          <div className="card-back">
            <div className="card-meta"><span>#{current.number} · {current.headword}</span><SourceBadge entry={current} /></div>
            <div className="answer-section"><span>意味</span><h2>{current.meaning}</h2></div>
            <div className="answer-grid">
              <div><span>熟語・構文</span>{current.syntax.map((item) => <p key={item}>{item}</p>)}</div>
              <div><span>例文</span>{current.examples.map((example) => <p key={example.sentence}><strong>{example.sentence}</strong><small>{example.translation}</small></p>)}</div>
            </div>
          </div>
        )}
      </button>

      <div className={`rating-grid ${flipped ? "visible" : ""}`} aria-hidden={!flipped}>
        {RATING_META.map((meta) => (
          <button key={meta.rating} className={meta.tone} onClick={() => onRate(meta.rating)} disabled={!flipped || busy}>
            <span><kbd>{meta.key}</kbd>{meta.label}</span>
            <strong>{formatInterval(previews[meta.rating].card.due, now)}</strong>
          </button>
        ))}
      </div>
    </section>
  );
}

function LibraryView({ entries, query, selected, reviews, onQuery, onSelect, onStudy }: {
  entries: VocabularyEntry[];
  query: string;
  selected?: VocabularyEntry;
  reviews: Record<string, StoredReview>;
  onQuery: (value: string) => void;
  onSelect: (id: string) => void;
  onStudy: () => void;
}) {
  const selectedReview = selected ? reviews[selected.id] : undefined;
  return (
    <div className="library-view">
      <section className="page-heading">
        <div><span className="section-kicker">語彙</span><h1>語彙を調べる</h1><p>単語、PDFページ、記憶状態を確認できます。</p></div>
        <button className="primary-button small" onClick={onStudy}>このデッキを学習 →</button>
      </section>
      <div className="library-grid">
        <div className="word-browser panel">
          <label className="search-box"><span>⌕</span><input value={query} onChange={(event) => onQuery(event.target.value)} placeholder="英単語・意味・構文・番号で検索" /></label>
          <div className="browser-count"><span>{entries.length}語</span><small>PDF OCR・要確認</small></div>
          <div className="browser-list">
            {entries.map((entry) => {
              const review = reviews[entry.id];
              return (
                <button key={entry.id} className={selected?.id === entry.id ? "selected" : ""} onClick={() => onSelect(entry.id)}>
                  <span className="word-number">{entry.number}</span>
                  <span><strong>{entry.headword}</strong><small>{entry.meaning}</small></span>
                  <i className={review ? "reviewed" : "new"}>{review ? "学習済" : "新規"}</i>
                </button>
              );
            })}
            {!entries.length && <div className="empty-search">一致する語がありません。</div>}
          </div>
        </div>
        {selected ? <article className="word-detail panel">
          <div className="detail-head"><span>#{selected.number}</span><SourceBadge entry={selected} /></div>
          <h2>{selected.headword}</h2>
          <p className="detail-meaning">{selected.meaning}</p>
          <div className="detail-section"><span>熟語・構文</span>{selected.syntax.map((item) => <p key={item}>{item}</p>)}</div>
          <div className="detail-section"><span>例文</span>{selected.examples.map((example) => <div className="example" key={example.sentence}><strong>{example.sentence}</strong><p>{example.translation}</p></div>)}</div>
          <div className="detail-footer">
            <div><span>記憶状態</span><strong>{selectedReview ? `${Math.round(selectedReview.stability * 10) / 10}日 安定` : "未学習"}</strong></div>
            <div><span>出典</span><strong>{selected.source.fileName}</strong></div>
          </div>
        </article> : <article className="word-detail panel empty-search">この区分の正式データはまだ準備中です。</article>}
      </div>
    </div>
  );
}

function SourcesView({ entries, suffix }: { entries: VocabularyEntry[]; suffix: string }) {
  return (
    <div className="sources-view">
      <section className="page-heading">
        <div><span className="section-kicker">収録状況</span><h1>データ</h1><p>PDF、収録状況、書き出しを確認できます。</p></div>
      </section>
      <div className="source-alert"><span>!</span><div><strong>全1,915語を収録しました</strong><p>掲載番号と最重要／発展の区分は監査済みです。語義・例文はPDF OCRの未校正データで、読めなかった箇所を推測の和訳で埋めていません。</p></div></div>
      <section className="source-layout">
        <div className="panel manifest-panel">
          <div className="panel-heading"><div><span className="section-kicker">PDF</span><h2>Google Drive 原本</h2></div><span className="page-total">印刷 {DATASET_STATUS.printedPages}頁</span></div>
          <div className="file-list">
            {SOURCE_FILES.map((file) => (
              <div key={file}>
                <span className="file-icon">PDF</span>
                <p><strong>{file}</strong><small>変更しない原本PDF</small></p>
                <span className="verified">収録済み</span>
              </div>
            ))}
          </div>
        </div>
        <div className="panel layers-panel">
          <div className="panel-heading"><div><span className="section-kicker">由来</span><h2>データの2層構造</h2></div></div>
          <div className="layer-card source-layer"><span>01</span><div><strong>source_entries.jsonl</strong><p>原典の表記、PDFページ、掲載番号、抽出原文、信頼度、原本ハッシュを保存。AI補足は混ぜません。</p></div></div>
          <div className="layer-link"><span>source_hash で固定リンク</span></div>
          <div className="layer-card learning-layer"><span>02</span><div><strong>learning_entries.jsonl</strong><p>学習用の語義整理、タグ、追加例文、FSRS設定を保存。各項目に由来と承認状態を付けます。</p></div></div>
          <div className="quality-gates"><strong>公開ゲート</strong><span>番号連続性</span><span>重複</span><span>空欄</span><span>OCR不一致</span><span>ページ照合</span></div>
        </div>
      </section>
      <section className="panel export-panel">
        <div><span className="section-kicker">書き出し</span><h2>学習アプリ向け出力</h2><p>マスターデータを変えず、用途ごとの搬入形式を生成します。</p></div>
        <div className="export-actions">
          <button onClick={() => exportAnki(entries, suffix)} disabled={!entries.length}><span>ANKI</span><strong>AnkiDroid TSV</strong><small>ID先頭・再インポート対応</small></button>
          <button onClick={() => exportNeoMemoria(entries, suffix)} disabled={!entries.length}><span>NEO</span><strong>NeoMemoria CSV</strong><small>7列・UTF-8 BOM</small></button>
        </div>
      </section>
    </div>
  );
}

function SettingsView() {
  return (
    <div className="settings-view">
      <section className="page-heading">
        <div><span className="section-kicker">設定</span><h1>学習設定</h1><p>復習の仕組みと操作方法を確認できます。</p></div>
      </section>
      <section className="settings-list">
        <article><span className="settings-symbol">↻</span><div><h2>復習タイミング</h2><p>思い出せる確率が約90%になることを目標に、単語ごとの次回学習日を自動調整します。</p><details><summary>仕組みの詳細</summary><p>FSRS-6を使用しています。復習期限が来た語を先に出し、新規語は1セッション最大{SESSION_NEW_LIMIT}語です。短期学習は1分・10分、忘れた語の再学習は10分を基準にします。</p></details></div></article>
        <article><span className="settings-symbol">⌨</span><div><h2>操作</h2><p><kbd>Space</kbd>で答えを表示し、<kbd>1</kbd>〜<kbd>4</kbd>で評価できます。iPadやスマホではカードと評価ボタンをタップしてください。</p></div></article>
        <article><span className="settings-symbol">◎</span><div><h2>学習データ</h2><p>ログイン中は端末をまたいで記憶状態を保存します。プレビュー表示では、その画面を閉じると評価は残りません。</p></div></article>
      </section>
    </div>
  );
}
