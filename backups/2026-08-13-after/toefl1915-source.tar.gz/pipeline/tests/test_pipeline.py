from __future__ import annotations

import sys
import unittest
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from validate_entries import canonical_source_hash, validate  # noqa: E402


def approved_source(number: int = 1):
    row = {
        "schema_version": "1.0.0",
        "corpus_id": "toefl-vocabulary-547",
        "source_entry_id": f"toefl-{number:04d}",
        "source_number": {"raw": f"{number:04d}", "value": number},
        "locator": {
            "drive_file_id": "fixture",
            "file_name": "fixture.pdf",
            "pdf_page_index": 1,
        },
        "capture": {
            "page_ocr_raw": "fixture",
            "segments": [
                {
                    "label_raw": "meaning",
                    "text_raw": "検査用",
                    "bbox_ratio": {"x": 0.1, "y": 0.1, "width": 0.4, "height": 0.1},
                    "confidence": 1.0,
                    "engine": "fixture",
                }
            ],
            "ocr_runs": [
                {
                    "engine": "fixture",
                    "engine_version": "1",
                    "model_id": None,
                    "languages": ["eng", "jpn"],
                    "dpi": 400,
                    "raw_artifact_sha256": "0" * 64,
                }
            ],
        },
        "approved_transcription": {
            "headword": "fixture",
            "segments": [{"label": "meaning", "text": "検査用"}],
            "approved_by": "test",
            "approved_at": "2026-08-09T00:00:00Z",
        },
        "status": "approved",
    }
    row["content_sha256"] = canonical_source_hash(row)
    return row


def approved_learning(source):
    provenance = {"kind": "source_transcription", "source_segment_indexes": [0]}
    return {
        "schema_version": "1.0.0",
        "learning_entry_id": source["source_entry_id"].replace("toefl", "learn-toefl"),
        "source_entry_id": source["source_entry_id"],
        "source_content_sha256": source["content_sha256"],
        "headword": "fixture",
        "headword_provenance": provenance,
        "meanings": [{"text": "検査用", "provenance": provenance}],
        "usages": [],
        "examples": [],
        "notes": [],
        "tags": ["fixture"],
        "approval": {"status": "approved"},
    }


class PipelineValidationTests(unittest.TestCase):
    def test_approved_source_and_learning_link_passes(self):
        source = approved_source()
        self.assertEqual(validate([source], [approved_learning(source)], True, True), [])

    def test_stale_learning_hash_is_rejected(self):
        source = approved_source()
        learning = approved_learning(source)
        learning["source_content_sha256"] = "0" * 64
        errors = validate([source], [learning], True, True)
        self.assertTrue(any("stale source hash" in error for error in errors))

    def test_unexplained_number_gap_is_rejected(self):
        first = approved_source(1)
        third = approved_source(3)
        errors = validate([first, third], [], False, True)
        self.assertIn("source numbers are not contiguous", errors)


if __name__ == "__main__":
    unittest.main()
