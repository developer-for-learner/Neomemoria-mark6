# Sol照合プロンプト

Luna転記JSONL、元ページ画像、Tesseract TSVを同時に確認する。

- 元画像にない文字をsource欄へ追加しない。
- 表記揺れを正規化しない。
- 番号、見出し語、各領域の境界を画像上で再確認する。
- Tesseractとの差がある箇所は、画像を根拠に採否を決めてissueへ残す。
- 語義の妥当性ではなく、印刷内容との一致だけを判定する。
- 承認転記を作成したら、validatorと同じcanonical JSONでcontent SHA-256を計算する。
- 一致を証明できない項目は `needs_review` のまま残す。
