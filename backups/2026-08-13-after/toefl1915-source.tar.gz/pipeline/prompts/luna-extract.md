# Luna転記プロンプト

このページ画像は変更不能な原典です。要約、補完、言い換え、誤字修正、意味推測を禁止します。

1. 各掲載番号をページ上の順序で検出する。
2. 番号ごとに見出し語と印刷されている全領域を分ける。
3. 各領域について、ラベルの原文、本文の原文、ページ全体に対する0〜1の相対座標を返す。
4. 判読できない文字は推測せず `□` とし、confidenceを下げる。
5. ヘッダー、フッター、隣の項目を混ぜない。
6. ページをまたぐ項目は `issues` に `page_boundary` を付ける。
7. JSONL以外を出力しない。

出力は `pipeline/schema/source-entry.schema.json` に従う。ただし最初の転記では `status` を `captured` とし、`approved_transcription` と `content_sha256` は出力しない。`ocr_runs.engine` は `chatgpt-vision`、`model_id` は実際のLunaモデルIDにする。
