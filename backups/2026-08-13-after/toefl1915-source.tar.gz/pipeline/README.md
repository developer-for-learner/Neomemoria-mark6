# PDF抽出パイプライン

## 採用方式

画像PDFをそのまま一発OCRして学習データにする方式は採用しません。次の二系統を突き合わせます。

1. 400dpiで各ページをPNG化し、ページ画像とハッシュを固定する。
2. Lunaで掲載番号・見出し語・各印刷領域を、要約せず構造化転記する。
3. Tesseract `eng+jpn` のTSVを独立した機械照合用ベースラインとして保存する。
4. Solで番号連続性、領域座標、文字列差分、ページまたぎを検査する。
5. 不一致・低信頼度だけを目視レビューへ送り、承認後に内容ハッシュを固定する。

Lunaは転記量の多い処理に使いますが、意味の補完・表現の改善・例文生成は `source_entries.jsonl` では禁止します。追加学習情報は必ず `learning_entries.jsonl` に分離し、項目ごとに由来を記録します。

## データの流れ

```mermaid
flowchart TD
  A[変更しないPDF] --> B[400dpiページ画像]
  B --> C[Luna 構造化転記]
  B --> D[Tesseract 独立OCR]
  C --> E[Sol 差分・連番検査]
  D --> E
  E --> F[source_entries.jsonl]
  F --> G[learning_entries.jsonl]
  G --> H[サイト / NeoMemoria / Anki]
```

## 品質ゲート

- 6ファイル・547ページとmanifestが一致する
- PDFとページ画像のSHA-256が固定されている
- 掲載番号に重複・逆転・意図しない欠番がない
- 見出し語が印刷領域と一致する
- ヘッダー、フッター、隣接欄が混入していない
- Lunaと独立OCRの差分が説明済みである
- 原典欄にAI生成文が混ざっていない
- 承認済みsource hashとlearning側の参照hashが一致する
- 7列CSVで情報が落ちる場合、NeoMemoria出力を停止する

## 実行例

原本をローカルへ取得した後、まずページ画像を作ります。

```bash
python3 pipeline/scripts/render_pages.py \
  /path/to/TOEFL単語p1〜99.pdf \
  --drive-file-id 17ZKBb8qR88wJy5qyHofXPoFN8Md-vGmQ \
  --out pipeline/work/p001-099 \
  --baseline-ocr
```

JSONLが揃ったら整合性を検査し、承認済みレコードだけを書き出します。

```bash
python3 pipeline/scripts/validate_entries.py \
  --source source_entries.jsonl \
  --learning learning_entries.jsonl \
  --require-approved --require-contiguous

python3 pipeline/scripts/export_entries.py \
  --source source_entries.jsonl \
  --learning learning_entries.jsonl \
  --out exports
```

`export_entries.py` は、NeoMemoriaの7列で3件目以降の例文が落ちる場合に既定で失敗します。必要なら元データを保ったままAnki TSVを使うか、明示的に `--allow-lossy-neomemoria` を指定します。

## 現在の制約

Driveではファイル一覧・ID・サイズ・ページ構成を確認済みですが、この実行環境ではスキャンPDFのバイナリをローカルファイルとして受け取れていません。そのため本番転記は開始せず、サイトの10語は原典照合前データとして隔離しています。PDFがローカル化できた時点で同じmanifestを使って再開できます。
