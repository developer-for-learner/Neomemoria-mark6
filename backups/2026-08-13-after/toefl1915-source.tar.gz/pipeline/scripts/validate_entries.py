#!/usr/bin/env python3
"""Validate source/learning JSONL links without silently repairing content."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


class ValidationError(Exception):
    pass


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open(encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValidationError(f"{path}:{line_number}: {error}") from error
            if not isinstance(value, dict):
                raise ValidationError(f"{path}:{line_number}: object required")
            rows.append(value)
    return rows


def canonical_source_hash(row: dict[str, Any]) -> str:
    payload = {
        "source_entry_id": row.get("source_entry_id"),
        "source_number": row.get("source_number"),
        "locator": row.get("locator"),
        "approved_transcription": row.get("approved_transcription"),
    }
    encoded = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def validate_provenance(value: Any, where: str, errors: list[str]) -> None:
    require(isinstance(value, dict), f"{where}: provenance object required", errors)
    if not isinstance(value, dict):
        return
    kind = value.get("kind")
    require(
        kind in {"source_transcription", "ai_generated", "human_authored"},
        f"{where}: invalid provenance kind",
        errors,
    )
    if kind == "source_transcription":
        indexes = value.get("source_segment_indexes")
        require(
            isinstance(indexes, list) and all(isinstance(index, int) and index >= 0 for index in indexes),
            f"{where}: source transcription needs segment indexes",
            errors,
        )
    if kind == "ai_generated":
        require(bool(value.get("model_id")), f"{where}: AI item needs model_id", errors)


def validate(
    sources: list[dict[str, Any]],
    learning: list[dict[str, Any]],
    require_approved: bool,
    require_contiguous: bool,
) -> list[str]:
    errors: list[str] = []
    source_by_id: dict[str, dict[str, Any]] = {}
    numbers: list[int] = []

    for index, row in enumerate(sources, 1):
        prefix = f"source row {index}"
        entry_id = row.get("source_entry_id")
        require(isinstance(entry_id, str) and entry_id, f"{prefix}: source_entry_id required", errors)
        if entry_id in source_by_id:
            errors.append(f"{prefix}: duplicate source_entry_id {entry_id}")
        elif isinstance(entry_id, str):
            source_by_id[entry_id] = row
        number = row.get("source_number", {}).get("value") if isinstance(row.get("source_number"), dict) else None
        require(isinstance(number, int) and number > 0, f"{prefix}: positive source number required", errors)
        if isinstance(number, int):
            numbers.append(number)
        status = row.get("status")
        if require_approved:
            require(status == "approved", f"{prefix}: not approved", errors)
        if status == "approved":
            require(bool(row.get("approved_transcription")), f"{prefix}: approved transcription missing", errors)
            expected = canonical_source_hash(row)
            require(row.get("content_sha256") == expected, f"{prefix}: content hash mismatch", errors)

    if len(numbers) != len(set(numbers)):
        errors.append("source numbers contain duplicates")
    if require_contiguous and numbers:
        ordered = sorted(numbers)
        expected = list(range(ordered[0], ordered[-1] + 1))
        require(ordered == expected, "source numbers are not contiguous", errors)

    learning_ids: set[str] = set()
    for index, row in enumerate(learning, 1):
        prefix = f"learning row {index}"
        learning_id = row.get("learning_entry_id")
        require(isinstance(learning_id, str) and learning_id, f"{prefix}: learning_entry_id required", errors)
        if learning_id in learning_ids:
            errors.append(f"{prefix}: duplicate learning_entry_id {learning_id}")
        elif isinstance(learning_id, str):
            learning_ids.add(learning_id)
        source_id = row.get("source_entry_id")
        source = source_by_id.get(source_id)
        require(source is not None, f"{prefix}: missing source {source_id}", errors)
        if source is not None:
            require(
                row.get("source_content_sha256") == source.get("content_sha256"),
                f"{prefix}: stale source hash",
                errors,
            )
        approval = row.get("approval", {})
        if require_approved:
            require(isinstance(approval, dict) and approval.get("status") == "approved", f"{prefix}: not approved", errors)
        validate_provenance(row.get("headword_provenance"), f"{prefix}.headword", errors)
        for field in ("meanings", "usages", "examples", "notes"):
            values = row.get(field, [])
            require(isinstance(values, list), f"{prefix}.{field}: array required", errors)
            if isinstance(values, list):
                for item_index, item in enumerate(values):
                    provenance = item.get("provenance") if isinstance(item, dict) else None
                    validate_provenance(provenance, f"{prefix}.{field}[{item_index}]", errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--learning", type=Path, required=True)
    parser.add_argument("--require-approved", action="store_true")
    parser.add_argument("--require-contiguous", action="store_true")
    args = parser.parse_args()
    errors = validate(
        read_jsonl(args.source),
        read_jsonl(args.learning),
        args.require_approved,
        args.require_contiguous,
    )
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("Validation passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
