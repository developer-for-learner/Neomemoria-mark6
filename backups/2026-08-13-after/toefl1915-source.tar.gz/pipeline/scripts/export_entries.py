#!/usr/bin/env python3
"""Export approved, source-linked learning entries to compatible formats."""

from __future__ import annotations

import argparse
import csv
import html
import json
from pathlib import Path
from typing import Any


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8-sig") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def item_text(item: dict[str, Any]) -> str:
    return str(item.get("text", "")).strip()


def usage_text(item: dict[str, Any]) -> str:
    pattern = str(item.get("pattern", "")).strip()
    gloss = str(item.get("gloss") or "").strip()
    return f"{pattern}（{gloss}）" if gloss else pattern


def example_text(item: dict[str, Any]) -> str:
    sentence = str(item.get("sentence", "")).strip()
    translation = str(item.get("translation") or "").strip()
    return f"{sentence}（{translation}）" if translation else sentence


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--learning", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--allow-lossy-neomemoria", action="store_true")
    args = parser.parse_args()

    sources = {row["source_entry_id"]: row for row in read_jsonl(args.source)}
    learning = [
        row
        for row in read_jsonl(args.learning)
        if row.get("approval", {}).get("status") == "approved"
    ]
    learning.sort(key=lambda row: sources[row["source_entry_id"]]["source_number"]["value"])

    for row in learning:
        source = sources.get(row["source_entry_id"])
        if not source or source.get("status") != "approved":
            raise SystemExit(f"unapproved or missing source: {row['source_entry_id']}")
        if row.get("source_content_sha256") != source.get("content_sha256"):
            raise SystemExit(f"stale source hash: {row['learning_entry_id']}")
        if len(row.get("examples", [])) > 2 and not args.allow_lossy_neomemoria:
            raise SystemExit(
                f"NeoMemoria 7-column export would drop examples: {row['learning_entry_id']}"
            )

    args.out.mkdir(parents=True, exist_ok=True)
    neo_path = args.out / "toefl_neomemoria.csv"
    with neo_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["No", "word", "meaning", "syntax", "example1", "example2", "emoji"])
        for row in learning:
            source = sources[row["source_entry_id"]]
            examples = [example_text(item) for item in row.get("examples", [])]
            writer.writerow(
                [
                    source["source_number"]["raw"],
                    row["headword"],
                    "、".join(item_text(item) for item in row["meanings"]),
                    "、".join(usage_text(item) for item in row.get("usages", [])),
                    examples[0] if examples else "",
                    examples[1] if len(examples) > 1 else "",
                    row.get("emoji", ""),
                ]
            )

    anki_path = args.out / "toefl_anki.tsv"
    with anki_path.open("w", encoding="utf-8-sig", newline="") as handle:
        for row in learning:
            source = sources[row["source_entry_id"]]
            locator = source["locator"]
            values = [
                row["source_entry_id"],
                row["headword"],
                "、".join(item_text(item) for item in row["meanings"]),
                "<br>".join(html.escape(usage_text(item)) for item in row.get("usages", [])),
                "<hr>".join(html.escape(example_text(item)) for item in row.get("examples", [])),
                f"{locator['file_name']} / PDF p.{locator['pdf_page_index']}",
                " ".join(row.get("tags", [])),
            ]
            handle.write("\t".join(values) + "\r\n")

    print(f"Wrote {neo_path} and {anki_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
