#!/usr/bin/env python3
"""Render immutable PDF pages and optionally record a Tesseract TSV baseline."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, check=True, text=True, capture_output=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--drive-file-id", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--first", type=int, default=1)
    parser.add_argument("--last", type=int)
    parser.add_argument("--dpi", type=int, default=400)
    parser.add_argument("--baseline-ocr", action="store_true")
    args = parser.parse_args()

    if not args.pdf.is_file():
        parser.error(f"PDF not found: {args.pdf}")
    if args.first < 1 or (args.last is not None and args.last < args.first):
        parser.error("invalid page range")
    if not shutil.which("pdftoppm"):
        parser.error("pdftoppm is required")

    args.out.mkdir(parents=True, exist_ok=True)
    prefix = args.out / "page"
    command = [
        "pdftoppm",
        "-png",
        "-r",
        str(args.dpi),
        "-f",
        str(args.first),
    ]
    if args.last is not None:
        command.extend(["-l", str(args.last)])
    command.extend([str(args.pdf), str(prefix)])
    run(command)

    ocr_version = None
    if args.baseline_ocr:
        if not shutil.which("tesseract"):
            parser.error("tesseract is required for --baseline-ocr")
        languages = run(["tesseract", "--list-langs"]).stdout.splitlines()
        missing = sorted({"eng", "jpn"} - set(languages))
        if missing:
            parser.error(f"missing Tesseract language data: {', '.join(missing)}")
        ocr_version = run(["tesseract", "--version"]).stdout.splitlines()[0]

    pages = []
    for image in sorted(args.out.glob("page-*.png")):
        item = {
            "file": image.name,
            "sha256": sha256(image),
            "size_bytes": image.stat().st_size,
        }
        if args.baseline_ocr:
            tsv_path = image.with_suffix(".tesseract.tsv")
            result = run(
                [
                    "tesseract",
                    str(image),
                    "stdout",
                    "-l",
                    "eng+jpn",
                    "--psm",
                    "6",
                    "tsv",
                ]
            )
            tsv_path.write_text(result.stdout, encoding="utf-8")
            item["tesseract_tsv"] = tsv_path.name
            item["tesseract_tsv_sha256"] = sha256(tsv_path)
        pages.append(item)

    manifest = {
        "schema_version": "1.0.0",
        "drive_file_id": args.drive_file_id,
        "source_pdf": args.pdf.name,
        "source_pdf_sha256": sha256(args.pdf),
        "dpi": args.dpi,
        "first_pdf_page": args.first,
        "last_pdf_page": args.last,
        "renderer": run(["pdftoppm", "-v"]).stderr.splitlines()[0],
        "baseline_ocr": ocr_version,
        "pages": pages,
    }
    (args.out / "batch-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Rendered {len(pages)} pages into {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
