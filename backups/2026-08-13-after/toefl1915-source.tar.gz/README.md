# TOEFL学習

Google Drive上の547ページの語彙PDFを、出典を失わずに学習へ変換する個人用ChatGPT Siteです。

## 方針

- PDF原本は変更しません。
- 原典転記 (`source_entries.jsonl`) と学習用補足 (`learning_entries.jsonl`) を分離します。
- AI生成の語義・用例を原典由来として扱いません。
- 承認済みレコードだけをサイト・NeoMemoria・AnkiDroidへ出力します。
- 復習間隔は `ts-fsrs` のFSRS-6で計算し、利用者ごとの状態をD1へ保存します。

現在サイトに含まれる10語はUIと変換処理の動作確認用です。見出し語と掲載番号以外は原典照合前の暫定データとして、画面上でも明示しています。

## 構成

- `app/`: Sitesの画面と復習API
- `db/`: D1 / Drizzleスキーマ
- `pipeline/`: PDFの抽出、出典固定、検証、互換出力の仕様とスクリプト
- `drizzle/`: 生成済みD1 migration

## 検証

```bash
npm run lint
npm run build
python3 -m unittest discover -s pipeline/tests
```

PDFのローカル原本が得られたら、`pipeline/README.md` の手順でページ画像を固定し、Lunaによる構造化転記と独立OCRの差分をSolで検査します。
