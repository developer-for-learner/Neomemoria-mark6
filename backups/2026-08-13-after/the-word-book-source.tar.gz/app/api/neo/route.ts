import {
  and,
  asc,
  desc,
  eq,
  inArray,
  isNull,
  lte,
  sql,
} from "drizzle-orm";
import { createEmptyCard, fsrs, Rating, type Card as FsrsCard } from "ts-fsrs";
import { getDb } from "../../../db";
import { cards, decks, reviewLogs, reviewStates } from "../../../db/schema";
import { getChatGPTUser } from "../../chatgpt-auth";
import { OFFICIAL_CONTENT_VERSION, OFFICIAL_DATASET_VERSION, OFFICIAL_VOCABULARY, officialDatasetReady } from "../../official-vocabulary";

export const dynamic = "force-dynamic";

const scheduler = fsrs({
  request_retention: 0.9,
  maximum_interval: 36500,
  enable_fuzz: true,
  enable_short_term: true,
  learning_steps: ["1m", "10m"],
  relearning_steps: ["10m"],
});

type ReviewStateRow = typeof reviewStates.$inferSelect;
type Database = Awaited<ReturnType<typeof getDb>>;
type ReviewSnapshot = Omit<
  typeof reviewStates.$inferInsert,
  "id" | "ownerEmail" | "cardId"
>;

function message(error: unknown) {
  return error instanceof Error ? error.message : "データベース処理に失敗しました";
}

function rowToCard(row: ReviewStateRow): FsrsCard {
  return {
    due: new Date(row.dueAt),
    stability: row.stability,
    difficulty: row.difficulty,
    elapsed_days: row.elapsedDays,
    scheduled_days: row.scheduledDays,
    learning_steps: row.learningSteps,
    reps: row.reps,
    lapses: row.lapses,
    state: row.state,
    last_review: row.lastReview ? new Date(row.lastReview) : undefined,
  } as FsrsCard;
}

function cardToSnapshot(card: FsrsCard): ReviewSnapshot {
  return {
    dueAt: card.due.toISOString(),
    stability: card.stability,
    difficulty: card.difficulty,
    elapsedDays: card.elapsed_days,
    scheduledDays: card.scheduled_days,
    learningSteps: card.learning_steps,
    reps: card.reps,
    lapses: card.lapses,
    state: card.state,
    lastReview: card.last_review?.toISOString() ?? null,
    updatedAt: new Date().toISOString(),
  };
}

function previousSnapshot(row: ReviewStateRow): ReviewSnapshot {
  return {
    dueAt: row.dueAt,
    stability: row.stability,
    difficulty: row.difficulty,
    elapsedDays: row.elapsedDays,
    scheduledDays: row.scheduledDays,
    learningSteps: row.learningSteps,
    reps: row.reps,
    lapses: row.lapses,
    state: row.state,
    lastReview: row.lastReview,
    updatedAt: row.updatedAt,
  };
}

function dayInJapan(iso: string) {
  return new Date(new Date(iso).getTime() + 9 * 60 * 60 * 1000)
    .toISOString()
    .slice(0, 10);
}

function streakFromLogs(logs: Array<{ reviewedAt: string }>) {
  const activeDays = [...new Set(logs.map((log) => dayInJapan(log.reviewedAt)))].sort().reverse();
  if (!activeDays.length) return 0;
  const today = dayInJapan(new Date().toISOString());
  const yesterday = dayInJapan(new Date(Date.now() - 86400000).toISOString());
  if (activeDays[0] !== today && activeDays[0] !== yesterday) return 0;
  let streak = 1;
  let cursor = new Date(`${activeDays[0]}T00:00:00+09:00`);
  for (let index = 1; index < activeDays.length; index += 1) {
    cursor = new Date(cursor.getTime() - 86400000);
    if (activeDays[index] !== dayInJapan(cursor.toISOString())) break;
    streak += 1;
  }
  return streak;
}

async function requireIdentity() {
  const user = await getChatGPTUser();
  if (!user) return null;
  return user.email;
}

async function ownerKey(ownerEmail: string) {
  const bytes = new TextEncoder().encode(ownerEmail.toLocaleLowerCase());
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest).slice(0, 8)).map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function ensureOfficialDecks(db: Database, ownerEmail: string) {
  if (!officialDatasetReady()) return;
  const owner = await ownerKey(ownerEmail);
  const definitions = [
    { key: "core", name: "TOEFL 1915｜最重要単語（809語）", description: `PDFのCore Vocabulary List順。監査済み完全版（${OFFICIAL_CONTENT_VERSION}）。`, values: OFFICIAL_VOCABULARY.filter((card) => card.level === "core") },
    { key: "expanded", name: "TOEFL 1915｜発展単語（1106語）", description: `PDFのExpanded Vocabulary List順。監査済み完全版（${OFFICIAL_CONTENT_VERSION}）。`, values: OFFICIAL_VOCABULARY.filter((card) => card.level === "expanded") },
    { key: "combined", name: "TOEFL 1915｜最重要＋発展（1915語）", description: `掲載番号順に統合した監査済み完全版（${OFFICIAL_CONTENT_VERSION}）。`, values: OFFICIAL_VOCABULARY },
  ] as const;
  for (const definition of definitions) {
    const deckId = `official-toefl-${OFFICIAL_DATASET_VERSION}-${owner}-${definition.key}`;
    const existing = await db
      .select({ description: decks.description, cardCount: sql<number>`count(${cards.id})` })
      .from(decks)
      .leftJoin(cards, eq(cards.deckId, decks.id))
      .where(eq(decks.id, deckId))
      .groupBy(decks.id)
      .get();
    if (existing?.description === definition.description && Number(existing.cardCount) === definition.values.length) continue;
    const deckCards = definition.values.map((card) => ({ id: `${deckId}-${String(card.number).padStart(4, "0")}`, deckId, sortOrder: card.number, word: card.word, meaning: card.meaning, syntax: card.syntax, example1: card.example1, example2: card.example2, emoji: card.emoji }));
    const chunks = Array.from({ length: Math.ceil(deckCards.length / 40) }, (_, index) => deckCards.slice(index * 40, index * 40 + 40));
    await db.batch([
      db.insert(decks).values({ id: deckId, ownerEmail, name: definition.name, description: definition.description }).onConflictDoUpdate({ target: decks.id, set: { name: definition.name, description: definition.description, updatedAt: new Date().toISOString() } }),
      ...chunks.map((chunk) => db.insert(cards).values(chunk).onConflictDoUpdate({ target: cards.id, set: { word: sql`excluded.word`, meaning: sql`excluded.meaning`, syntax: sql`excluded.syntax`, example1: sql`excluded.example_1`, example2: sql`excluded.example_2`, emoji: sql`excluded.emoji` } })),
    ]);
  }
}

export async function GET(request: Request) {
  const ownerEmail = await requireIdentity();
  if (!ownerEmail) {
    return Response.json({
      authenticated: false,
      decks: [],
      stats: { due: 0, reviewed: 0, retention: null, streak: 0, activity: Array(12).fill(0) },
    });
  }

  try {
    const db = await getDb();
    await ensureOfficialDecks(db, ownerEmail);
    const url = new URL(request.url);
    const deckId = url.searchParams.get("deck");
    if (deckId) {
      const deck = await db
        .select()
        .from(decks)
        .where(and(eq(decks.id, deckId), eq(decks.ownerEmail, ownerEmail)))
        .get();
      if (!deck) {
        return Response.json({ error: "デッキが見つかりません" }, { status: 404 });
      }
      const deckCards = await db
        .select()
        .from(cards)
        .where(eq(cards.deckId, deckId))
        .orderBy(asc(cards.sortOrder));
      const states = deckCards.length
        ? await db
            .select()
            .from(reviewStates)
            .where(
              and(
                eq(reviewStates.ownerEmail, ownerEmail),
                inArray(
                  reviewStates.cardId,
                  deckCards.map((card) => card.id),
                ),
              ),
            )
        : [];
      return Response.json({ authenticated: true, deck, cards: deckCards, reviewStates: states });
    }

    const userDecks = await db
      .select({ deck: decks, cardCount: sql<number>`count(${cards.id})` })
      .from(decks)
      .leftJoin(cards, eq(cards.deckId, decks.id))
      .where(eq(decks.ownerEmail, ownerEmail))
      .groupBy(decks.id)
      .orderBy(desc(decks.updatedAt));
    const due = await db
      .select({ count: sql<number>`count(*)` })
      .from(reviewStates)
      .where(
        and(
          eq(reviewStates.ownerEmail, ownerEmail),
          lte(reviewStates.dueAt, new Date().toISOString()),
        ),
      )
      .get();
    const logs = await db
      .select({ rating: reviewLogs.rating, reviewedAt: reviewLogs.reviewedAt })
      .from(reviewLogs)
      .where(and(eq(reviewLogs.ownerEmail, ownerEmail), isNull(reviewLogs.undoneAt)))
      .orderBy(desc(reviewLogs.reviewedAt));
    const correct = logs.filter((log) => log.rating >= Rating.Good).length;
    const activity = Array(12).fill(0) as number[];
    const start = Date.now() - 12 * 7 * 86400000;
    for (const log of logs) {
      const bucket = Math.floor((new Date(log.reviewedAt).getTime() - start) / (7 * 86400000));
      if (bucket >= 0 && bucket < 12) activity[bucket] += 1;
    }
    return Response.json({
      authenticated: true,
      decks: userDecks.map((row) => ({ ...row.deck, cardCount: Number(row.cardCount), isOfficial: row.deck.id.startsWith("official-toefl-") })),
      stats: {
        due: Number(due?.count ?? 0),
        reviewed: logs.length,
        retention: logs.length ? Math.round((correct / logs.length) * 100) : null,
        streak: streakFromLogs(logs),
        activity,
      },
    });
  } catch (error) {
    return Response.json({ error: message(error) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const ownerEmail = await requireIdentity();
  if (!ownerEmail) {
    return Response.json(
      { error: "プレビューでは保存できません。公開版をChatGPTで開いてください。" },
      { status: 401 },
    );
  }

  try {
    const payload = (await request.json()) as Record<string, unknown>;
    const db = await getDb();

    if (payload.action === "create-deck") {
      const name = String(payload.name ?? "").trim().slice(0, 120);
      const description = String(payload.description ?? "").trim().slice(0, 500);
      const rawCards = Array.isArray(payload.cards) ? payload.cards.slice(0, 5000) : [];
      if (!name || rawCards.length === 0) {
        return Response.json({ error: "デッキ名とカードが必要です" }, { status: 400 });
      }
      const deckId = crypto.randomUUID();
      const usedSortOrders = new Set<number>();
      let nextSortOrder = 1;
      const deckCards = rawCards
        .map((item, index) => {
          const card = item as Record<string, unknown>;
          const requested = Number(card.number ?? card.sortOrder ?? index + 1);
          let sortOrder = Number.isSafeInteger(requested) && requested > 0 ? requested : index + 1;
          while (usedSortOrders.has(sortOrder)) {
            while (usedSortOrders.has(nextSortOrder)) nextSortOrder += 1;
            sortOrder = nextSortOrder;
          }
          usedSortOrders.add(sortOrder);
          return {
            id: crypto.randomUUID(),
            deckId,
            sortOrder,
            word: String(card.word ?? "").trim().slice(0, 500),
            meaning: String(card.meaning ?? "").trim().slice(0, 2000),
            syntax: String(card.syntax ?? "").trim().slice(0, 2000),
            example1: String(card.example1 ?? "").trim().slice(0, 4000),
            example2: String(card.example2 ?? "").trim().slice(0, 4000),
            emoji: String(card.emoji ?? "").trim().slice(0, 32),
          };
        })
        .filter((card) => card.word && card.meaning);
      if (!deckCards.length) {
        return Response.json(
          { error: "単語と意味があるカードを1枚以上追加してください" },
          { status: 400 },
        );
      }
      const chunks = Array.from(
        { length: Math.ceil(deckCards.length / 40) },
        (_, index) => deckCards.slice(index * 40, index * 40 + 40),
      );
      await db.batch([
        db.insert(decks).values({ id: deckId, ownerEmail, name, description }),
        ...chunks.map((chunk) => db.insert(cards).values(chunk)),
      ]);
      return Response.json({ deckId, cardCount: deckCards.length }, { status: 201 });
    }

    if (payload.action === "review") {
      const cardId = String(payload.cardId ?? "").trim();
      const rating = Number(payload.rating);
      const mode = String(payload.mode ?? "normal");
      if (
        !cardId ||
        ![Rating.Again, Rating.Hard, Rating.Good, Rating.Easy].includes(rating) ||
        !["normal", "simple", "oni"].includes(mode)
      ) {
        return Response.json({ error: "カード、評価、またはモードが不正です" }, { status: 400 });
      }
      const ownedCard = await db
        .select({ id: cards.id })
        .from(cards)
        .innerJoin(decks, and(eq(cards.deckId, decks.id), eq(decks.ownerEmail, ownerEmail)))
        .where(eq(cards.id, cardId))
        .get();
      if (!ownedCard) {
        return Response.json({ error: "カードが見つかりません" }, { status: 404 });
      }
      const current = await db
        .select()
        .from(reviewStates)
        .where(
          and(
            eq(reviewStates.cardId, cardId),
            eq(reviewStates.ownerEmail, ownerEmail),
          ),
        )
        .get();
      const now = new Date();
      const before = current ? rowToCard(current) : createEmptyCard(now);
      const after = scheduler.next(before, now, rating).card;
      const values = cardToSnapshot(after);
      const stateId = current?.id ?? crypto.randomUUID();
      const logId = crypto.randomUUID();
      await db.batch([
        db
          .insert(reviewStates)
          .values({ id: stateId, ownerEmail, cardId, ...values })
          .onConflictDoUpdate({
            target: [reviewStates.ownerEmail, reviewStates.cardId],
            set: values,
          }),
        db.insert(reviewLogs).values({
          id: logId,
          reviewStateId: stateId,
          ownerEmail,
          cardId,
          rating,
          mode,
          stateExisted: Boolean(current),
          stateBeforeJson: current ? JSON.stringify(previousSnapshot(current)) : null,
          stateAfterJson: JSON.stringify(values),
          reviewedAt: now.toISOString(),
        }),
      ]);
      return Response.json({ logId, state: values });
    }

    if (payload.action === "undo-review") {
      const logId = String(payload.logId ?? "").trim();
      const log = await db
        .select()
        .from(reviewLogs)
        .where(
          and(
            eq(reviewLogs.id, logId),
            eq(reviewLogs.ownerEmail, ownerEmail),
            isNull(reviewLogs.undoneAt),
          ),
        )
        .get();
      if (!log) {
        return Response.json({ error: "取り消せるレビューがありません" }, { status: 404 });
      }
      const latest = await db
        .select({ id: reviewLogs.id })
        .from(reviewLogs)
        .where(
          and(
            eq(reviewLogs.ownerEmail, ownerEmail),
            eq(reviewLogs.cardId, log.cardId),
            isNull(reviewLogs.undoneAt),
          ),
        )
        .orderBy(desc(reviewLogs.reviewedAt))
        .limit(1);
      if (latest[0]?.id !== log.id) {
        return Response.json(
          { error: "この後の復習があるため取り消せません" },
          { status: 409 },
        );
      }
      const undoneAt = new Date().toISOString();
      let restoredState: { cardId: string; dueAt: string } | null = null;
      if (log.stateExisted && log.stateBeforeJson) {
        const previous = JSON.parse(log.stateBeforeJson) as ReviewSnapshot;
        restoredState = { cardId: log.cardId, dueAt: previous.dueAt };
        await db.batch([
          db
            .update(reviewStates)
            .set(previous)
            .where(
              and(
                eq(reviewStates.ownerEmail, ownerEmail),
                eq(reviewStates.cardId, log.cardId),
              ),
            ),
          db.update(reviewLogs).set({ undoneAt }).where(eq(reviewLogs.id, log.id)),
        ]);
      } else {
        await db.batch([
          db
            .delete(reviewStates)
            .where(
              and(
                eq(reviewStates.ownerEmail, ownerEmail),
                eq(reviewStates.cardId, log.cardId),
              ),
            ),
          db.update(reviewLogs).set({ undoneAt }).where(eq(reviewLogs.id, log.id)),
        ]);
      }
      return Response.json({ undone: true, state: restoredState });
    }

    return Response.json({ error: "不明な操作です" }, { status: 400 });
  } catch (error) {
    return Response.json({ error: message(error) }, { status: 500 });
  }
}
