export type ImportedCard = {
  number: number | null;
  word: string;
  meaning: string;
  syntax: string;
  example1: string;
  example2: string;
  emoji: string;
};

export function parseDelimited(raw: string, delimiter: string) {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const text = raw.replace(/^\uFEFF/, "");
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === delimiter && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((character === "\n" || character === "\r") && !quoted) {
      if (character === "\r" && text[index + 1] === "\n") index += 1;
      row.push(cell);
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += character;
    }
  }
  row.push(cell);
  if (row.some((value) => value.trim())) rows.push(row);
  return rows;
}

export function parseRows(raw: string, fileName: string): ImportedCard[] {
  const firstLine = raw.split(/\r?\n/, 1)[0] ?? "";
  const delimiter = fileName.toLowerCase().endsWith(".csv")
    ? ","
    : firstLine.includes("\t")
      ? "\t"
      : firstLine.includes(",")
        ? ","
        : "\t";
  const rows = parseDelimited(raw, delimiter);
  const cards: ImportedCard[] = [];

  for (const rawRow of rows) {
    const fields = rawRow.map((value) => value.trim());
    const first = (fields[0] ?? "").toLowerCase();
    const second = (fields[1] ?? "").toLowerCase();
    const numberedHeader = ["no", "no.", "number", "番号"].includes(first);
    const wordHeader = ["word", "単語"].includes(first) && ["meaning", "意味", "語義"].includes(second);
    if (numberedHeader || wordHeader) continue;
    if (fields.length < 2) continue;

    const hasLeadingNumber = fields.length >= 3 && /^#?\d+$/.test(fields[0] ?? "");
    const offset = hasLeadingNumber ? 1 : 0;
    const number = hasLeadingNumber ? Number((fields[0] ?? "").replace(/^#/, "")) : null;
    const remaining = fields.length - offset;
    const word = fields[offset] ?? "";
    const meaning = fields[offset + 1] ?? "";
    let syntax = "";
    let example1 = "";
    let example2 = "";
    let emoji = "";

    if (remaining >= 6) {
      syntax = fields[offset + 2] ?? "";
      example1 = fields[offset + 3] ?? "";
      example2 = fields[offset + 4] ?? "";
      emoji = fields[offset + 5] ?? "";
    } else if (remaining === 5) {
      example1 = fields[offset + 2] ?? "";
      example2 = fields[offset + 3] ?? "";
      emoji = fields[offset + 4] ?? "";
    } else if (remaining >= 4) {
      example1 = fields[offset + 2] ?? "";
      example2 = fields[offset + 3] ?? "";
    }

    if (word && meaning) {
      cards.push({ number, word, meaning, syntax, example1, example2, emoji });
    }
  }
  return cards;
}
