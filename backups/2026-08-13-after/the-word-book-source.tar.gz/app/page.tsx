import { getChatGPTUser } from "./chatgpt-auth";
import { NeoMemoriaApp } from "./neomemoria-app";

export const dynamic = "force-dynamic";

export default async function Home() {
  const user = await getChatGPTUser();
  return <NeoMemoriaApp user={user} />;
}
