import { sql } from "drizzle-orm";
import {
  index,
  integer,
  real,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

export const decks = sqliteTable(
  "decks",
  {
    id: text("id").primaryKey(),
    ownerEmail: text("owner_email").notNull(),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [index("decks_owner_idx").on(table.ownerEmail)],
);

export const cards = sqliteTable(
  "cards",
  {
    id: text("id").primaryKey(),
    deckId: text("deck_id")
      .notNull()
      .references(() => decks.id, { onDelete: "cascade" }),
    sortOrder: integer("sort_order").notNull().default(0),
    word: text("word").notNull(),
    meaning: text("meaning").notNull(),
    syntax: text("syntax").notNull().default(""),
    example1: text("example_1").notNull().default(""),
    example2: text("example_2").notNull().default(""),
    emoji: text("emoji").notNull().default(""),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("cards_deck_idx").on(table.deckId),
    uniqueIndex("cards_deck_order_unique").on(table.deckId, table.sortOrder),
  ],
);

export const reviewStates = sqliteTable(
  "review_states",
  {
    id: text("id").primaryKey(),
    ownerEmail: text("owner_email").notNull(),
    cardId: text("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    dueAt: text("due_at").notNull(),
    stability: real("stability").notNull().default(0),
    difficulty: real("difficulty").notNull().default(0),
    elapsedDays: integer("elapsed_days").notNull().default(0),
    scheduledDays: integer("scheduled_days").notNull().default(0),
    learningSteps: integer("learning_steps").notNull().default(0),
    reps: integer("reps").notNull().default(0),
    lapses: integer("lapses").notNull().default(0),
    state: integer("state").notNull().default(0),
    lastReview: text("last_review"),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("review_states_owner_card_unique").on(
      table.ownerEmail,
      table.cardId,
    ),
    index("review_states_owner_due_idx").on(table.ownerEmail, table.dueAt),
  ],
);

export const reviewLogs = sqliteTable(
  "review_logs",
  {
    id: text("id").primaryKey(),
    reviewStateId: text("review_state_id").notNull(),
    ownerEmail: text("owner_email").notNull(),
    cardId: text("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    rating: integer("rating").notNull(),
    mode: text("mode").notNull(),
    stateExisted: integer("state_existed", { mode: "boolean" }).notNull(),
    stateBeforeJson: text("state_before_json"),
    stateAfterJson: text("state_after_json").notNull(),
    reviewedAt: text("reviewed_at").notNull(),
    undoneAt: text("undone_at"),
  },
  (table) => [
    index("review_logs_owner_reviewed_idx").on(
      table.ownerEmail,
      table.reviewedAt,
    ),
    index("review_logs_owner_card_idx").on(table.ownerEmail, table.cardId),
  ],
);
