import assert from "node:assert/strict";
import test from "node:test";
import { parseRows } from "../app/import-parser.ts";

test("parses NeoMemoria 7-column CSV and preserves quoted commas", () => {
  const rows = parseRows(
    '\uFEFFNo,word,meaning,syntax,example1,example2,emoji\r\n1,follow,"従う, 続く",follow suit,Follow me.,私についてきて。,📋',
    "deck.csv",
  );
  assert.deepEqual(rows, [
    {
      number: 1,
      word: "follow",
      meaning: "従う, 続く",
      syntax: "follow suit",
      example1: "Follow me.",
      example2: "私についてきて。",
      emoji: "📋",
    },
  ]);
});

test("keeps empty 7-column fields in their original positions", () => {
  const rows = parseRows("2,plain,簡素な,,a plain room,,", "deck.csv");
  assert.equal(rows[0]?.syntax, "");
  assert.equal(rows[0]?.example1, "a plain room");
  assert.equal(rows[0]?.example2, "");
  assert.equal(rows[0]?.emoji, "");
});

test("supports 6-column legacy, 4-column, and 2-column TSV", () => {
  assert.deepEqual(parseRows("1\tword\t意味\texample\t訳\t🌱", "legacy.tsv")[0], {
    number: 1,
    word: "word",
    meaning: "意味",
    syntax: "",
    example1: "example",
    example2: "訳",
    emoji: "🌱",
  });
  assert.deepEqual(parseRows("term\t意味\texample\t訳", "four.tsv")[0], {
    number: null,
    word: "term",
    meaning: "意味",
    syntax: "",
    example1: "example",
    example2: "訳",
    emoji: "",
  });
  assert.deepEqual(parseRows("term\t意味", "two.txt")[0], {
    number: null,
    word: "term",
    meaning: "意味",
    syntax: "",
    example1: "",
    example2: "",
    emoji: "",
  });
});
