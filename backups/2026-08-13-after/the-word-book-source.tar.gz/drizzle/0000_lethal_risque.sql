CREATE TABLE `cards` (
	`id` text PRIMARY KEY NOT NULL,
	`deck_id` text NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`word` text NOT NULL,
	`meaning` text NOT NULL,
	`syntax` text DEFAULT '' NOT NULL,
	`example_1` text DEFAULT '' NOT NULL,
	`example_2` text DEFAULT '' NOT NULL,
	`emoji` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`deck_id`) REFERENCES `decks`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `cards_deck_idx` ON `cards` (`deck_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `cards_deck_order_unique` ON `cards` (`deck_id`,`sort_order`);--> statement-breakpoint
CREATE TABLE `decks` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_email` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `decks_owner_idx` ON `decks` (`owner_email`);--> statement-breakpoint
CREATE TABLE `review_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`review_state_id` text NOT NULL,
	`owner_email` text NOT NULL,
	`card_id` text NOT NULL,
	`rating` integer NOT NULL,
	`mode` text NOT NULL,
	`state_existed` integer NOT NULL,
	`state_before_json` text,
	`state_after_json` text NOT NULL,
	`reviewed_at` text NOT NULL,
	`undone_at` text,
	FOREIGN KEY (`card_id`) REFERENCES `cards`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `review_logs_owner_reviewed_idx` ON `review_logs` (`owner_email`,`reviewed_at`);--> statement-breakpoint
CREATE INDEX `review_logs_owner_card_idx` ON `review_logs` (`owner_email`,`card_id`);--> statement-breakpoint
CREATE TABLE `review_states` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_email` text NOT NULL,
	`card_id` text NOT NULL,
	`due_at` text NOT NULL,
	`stability` real DEFAULT 0 NOT NULL,
	`difficulty` real DEFAULT 0 NOT NULL,
	`elapsed_days` integer DEFAULT 0 NOT NULL,
	`scheduled_days` integer DEFAULT 0 NOT NULL,
	`learning_steps` integer DEFAULT 0 NOT NULL,
	`reps` integer DEFAULT 0 NOT NULL,
	`lapses` integer DEFAULT 0 NOT NULL,
	`state` integer DEFAULT 0 NOT NULL,
	`last_review` text,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`card_id`) REFERENCES `cards`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `review_states_owner_card_unique` ON `review_states` (`owner_email`,`card_id`);--> statement-breakpoint
CREATE INDEX `review_states_owner_due_idx` ON `review_states` (`owner_email`,`due_at`);