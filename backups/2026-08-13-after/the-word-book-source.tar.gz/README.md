# The Word Book

元のNeoMemoriaの使いやすさと7列CSV互換を受け継ぎ、ChatGPT Sites向けに再設計した個人用フラッシュカードサイトです。

## 主な機能

- ChatGPTの利用者情報でデッキと復習履歴を分離
- D1 / Drizzleによるデッキ、カード、FSRS状態、監査可能な復習ログの保存
- `ts-fsrs` によるFSRS-6スケジューリング
- Normal / Simple / 鬼（意味からスペル入力）の3モード
- 永続化したFSRS状態まで戻す直前レビューのUndo
- 2・4・6・7列のCSV / TSV / TXTインポート
- 7列NeoMemoria CSVと、安定IDを先頭に置くAnki TSVの出力
- 実ログだけを使う復習数、定着率、期限カード、ストリーク、12週アクティビティ
- デスクトップ、タブレット、モバイル対応

## 互換フォーマット

推奨の7列形式は次の通りです。

```csv
No,word,meaning,syntax,example1,example2,emoji
```

CSV解析は引用符内のカンマ、UTF-8 BOM、空欄位置を保持します。ヘッダーは自動判定し、6列legacy、4列、2列も読み込めます。

## セキュリティとデータ境界

- 独自パスワード、固定salt、自己発行bearer tokenは移植していません。
- APIはChatGPT identity headerを要求し、デッキ所有者をカード単位で再検査します。
- プレビューではサンプルデッキだけを表示し、保存しません。
- 本番の閲覧範囲はSitesのアクセス設定で所有者だけに制限します。

## 検証

```bash
npm run lint
./node_modules/.bin/tsc --noEmit
npm test
```

`npm test` はSites Workerのビルド／artifact検査、サーバーレンダリング、7列CSV・空欄・引用符・legacy形式の解析テストを実行します。
